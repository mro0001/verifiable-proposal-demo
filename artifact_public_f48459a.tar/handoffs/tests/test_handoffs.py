"""Tests for the handoffs, the plain file copies between layers.

Each handoff is called as a command, the way a scholar or the authors would run it.
Every file here is synthetic and written in the test.

Run from the repository root with python3 -m pytest -q handoffs/tests.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
HANDOFFS = ROOT / "handoffs"


def call(script, *args):
    return subprocess.run([sys.executable, str(HANDOFFS / script)] + [str(a) for a in args],
                          cwd=str(ROOT), capture_output=True, text=True)


def tree(folder):
    """Every file under a folder, as relative path to bytes."""
    folder = Path(folder)
    return {str(p.relative_to(folder)): p.read_bytes()
            for p in sorted(folder.rglob("*")) if p.is_file()}


# W1. The audit-to-project copy.

RECORDS = {
    "citation_log": "citation_log.yaml",
    "session_writes": "session_writes.jsonl",
    "rationales": "rationales.yaml",
}


def record_file(tmp_path, name, data):
    path = tmp_path / "audit_out" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path


def project(tmp_path):
    path = tmp_path / "project"
    path.mkdir()
    (path / "manuscript.md").write_text("A test manuscript.\n", encoding="utf-8")
    return path


@pytest.mark.parametrize("kind", sorted(RECORDS))
def test_each_record_lands_under_its_fixed_name_with_identical_bytes(tmp_path, kind):
    data = ("# written by a test\r\nkind: %s\n\xe9\x00tail" % kind).encode("latin-1")
    src = record_file(tmp_path, "any_name.out", data)
    proj = project(tmp_path)
    r = call("audit_to_project.py", "--record", kind, "--from", src, "--project", proj)
    assert r.returncode == 0, r.stderr
    dest = proj / "audit" / RECORDS[kind]
    assert dest.read_bytes() == data
    assert str(dest) in r.stdout
    assert sorted(tree(proj / "audit")) == [RECORDS[kind]]


def test_audit_folder_is_created_when_absent(tmp_path):
    src = record_file(tmp_path, "citation_log.yaml", b"citations: {}\n")
    proj = project(tmp_path)
    assert not (proj / "audit").exists()
    r = call("audit_to_project.py", "--record", "citation_log", "--from", src, "--project", proj)
    assert r.returncode == 0, r.stderr
    assert (proj / "audit").is_dir()


def test_second_copy_replaces_the_first(tmp_path):
    proj = project(tmp_path)
    first = record_file(tmp_path, "first.yaml", b"citations:\n  a: 1\n  b: 2\n  c: 3\n")
    second = record_file(tmp_path, "second.yaml", b"citations: {}\n")
    for src in (first, second):
        r = call("audit_to_project.py", "--record", "citation_log", "--from", src,
                 "--project", proj)
        assert r.returncode == 0, r.stderr
    assert (proj / "audit" / "citation_log.yaml").read_bytes() == b"citations: {}\n"


def test_copy_leaves_other_records_alone(tmp_path):
    proj = project(tmp_path)
    log = record_file(tmp_path, "log.yaml", b"citations: {}\n")
    writes = record_file(tmp_path, "writes.jsonl", b'{"path": "builds/x"}\n')
    call("audit_to_project.py", "--record", "citation_log", "--from", log, "--project", proj)
    call("audit_to_project.py", "--record", "session_writes", "--from", writes, "--project", proj)
    assert tree(proj / "audit") == {"citation_log.yaml": b"citations: {}\n",
                                    "session_writes.jsonl": b'{"path": "builds/x"}\n'}


def test_missing_record_file_exits_2_and_writes_nothing(tmp_path):
    proj = project(tmp_path)
    before = tree(proj)
    missing = tmp_path / "audit_out" / "nothing_here.yaml"
    r = call("audit_to_project.py", "--record", "citation_log", "--from", missing,
             "--project", proj)
    assert r.returncode == 2
    assert str(missing) in r.stderr
    assert tree(proj) == before
    assert not (proj / "audit").exists()


def test_missing_project_exits_2_and_writes_nothing(tmp_path):
    src = record_file(tmp_path, "log.yaml", b"citations: {}\n")
    missing = tmp_path / "no_project"
    r = call("audit_to_project.py", "--record", "citation_log", "--from", src,
             "--project", missing)
    assert r.returncode == 2
    assert str(missing) in r.stderr
    assert not missing.exists()


def test_unknown_record_kind_is_refused(tmp_path):
    src = record_file(tmp_path, "log.yaml", b"citations: {}\n")
    proj = project(tmp_path)
    before = tree(proj)
    r = call("audit_to_project.py", "--record", "transcripts", "--from", src, "--project", proj)
    assert r.returncode == 2
    assert "transcripts" in r.stderr
    assert tree(proj) == before


# W2. The project-to-references copy.

PROJECT_FILES = {
    "manuscript.md": b"A test manuscript [@dumont2014].\n",
    "slides.md": b"# Slides\n\nA slide [@nakamura2020].\n",
    "author_draft.md": b"A test manuscript.\n",
    "audit/citation_log.yaml": b"citations:\n  dumont2014:\n    introduced_by: ai\n",
    "refs.bib": b"@article{dumont2014, title={T}}\n",
}
REFERENCE_FILES = {
    "refs.yaml": b"dumont2014:\n  title: T\n",
    "metadata_cache.json": b"{}\n",
    "prior_checks.json": b"[]\n",
    "source_dumont2014.txt": b"ACCESS: fulltext\nSome text.\n",
    "source_nakamura2020.txt": b"ACCESS: abstract\nOther text.\n",
    "recorded_judge.json": b"{}\n",
    "recorded_second.json": b"{}\n",
    "expected_citation_log.yaml": b"citations: {}\n",
    "notes.txt": b"the scholar's notes\n",
}


def write_tree(folder, files):
    for name, data in files.items():
        path = folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    return folder


def references_setup(tmp_path, drop_project=(), drop_references=()):
    proj = write_tree(tmp_path / "project",
                      {k: v for k, v in PROJECT_FILES.items() if k not in drop_project})
    refs = write_tree(tmp_path / "references",
                      {k: v for k, v in REFERENCE_FILES.items() if k not in drop_references})
    return proj, refs


def test_inputs_folder_holds_exactly_the_named_files_with_identical_bytes(tmp_path):
    proj, refs = references_setup(tmp_path)
    to = tmp_path / "inputs" / "citations"
    r = call("project_to_references.py", "--project", proj, "--references", refs, "--to", to)
    assert r.returncode == 0, r.stderr
    assert tree(to) == {
        "draft.md": PROJECT_FILES["manuscript.md"],
        "author_draft.md": PROJECT_FILES["author_draft.md"],
        "citation_log.yaml": PROJECT_FILES["audit/citation_log.yaml"],
        "refs.yaml": REFERENCE_FILES["refs.yaml"],
        "metadata_cache.json": REFERENCE_FILES["metadata_cache.json"],
        "prior_checks.json": REFERENCE_FILES["prior_checks.json"],
        "source_dumont2014.txt": REFERENCE_FILES["source_dumont2014.txt"],
        "source_nakamura2020.txt": REFERENCE_FILES["source_nakamura2020.txt"],
    }
    assert not list(to.glob("recorded_*.json"))
    assert not (to / "expected_citation_log.yaml").exists()


def test_source_option_names_the_draft(tmp_path):
    proj, refs = references_setup(tmp_path)
    to = tmp_path / "inputs"
    r = call("project_to_references.py", "--project", proj, "--references", refs, "--to", to,
             "--source", "slides.md")
    assert r.returncode == 0, r.stderr
    assert (to / "draft.md").read_bytes() == PROJECT_FILES["slides.md"]


def test_references_copy_leaves_both_folders_unchanged(tmp_path):
    proj, refs = references_setup(tmp_path)
    before = (tree(proj), tree(refs))
    r = call("project_to_references.py", "--project", proj, "--references", refs,
             "--to", tmp_path / "inputs")
    assert r.returncode == 0, r.stderr
    assert (tree(proj), tree(refs)) == before


def test_existing_inputs_folder_is_refused(tmp_path):
    proj, refs = references_setup(tmp_path)
    to = tmp_path / "inputs"
    to.mkdir()
    (to / "draft.md").write_bytes(b"an earlier run's draft\n")
    r = call("project_to_references.py", "--project", proj, "--references", refs, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert tree(to) == {"draft.md": b"an earlier run's draft\n"}


def test_project_without_citation_log_is_refused(tmp_path):
    proj, refs = references_setup(tmp_path, drop_project=("audit/citation_log.yaml",))
    to = tmp_path / "inputs"
    r = call("project_to_references.py", "--project", proj, "--references", refs, "--to", to)
    assert r.returncode == 2
    assert str(proj / "audit" / "citation_log.yaml") in r.stderr
    assert not to.exists()


def test_references_folder_without_refs_yaml_is_refused(tmp_path):
    proj, refs = references_setup(tmp_path, drop_references=("refs.yaml",))
    to = tmp_path / "inputs"
    r = call("project_to_references.py", "--project", proj, "--references", refs, "--to", to)
    assert r.returncode == 2
    assert str(refs / "refs.yaml") in r.stderr
    assert not to.exists()


def test_every_missing_file_is_named(tmp_path):
    proj, refs = references_setup(tmp_path, drop_project=("author_draft.md",),
                                  drop_references=("prior_checks.json", "metadata_cache.json"))
    to = tmp_path / "inputs"
    r = call("project_to_references.py", "--project", proj, "--references", refs, "--to", to,
             "--source", "missing_draft.md")
    assert r.returncode == 2
    for path in (proj / "missing_draft.md", proj / "author_draft.md",
                 refs / "prior_checks.json", refs / "metadata_cache.json"):
        assert str(path) in r.stderr
    assert not to.exists()


# W3. The verification-to-pipeline copy.

STREAMS = ("prose", "citations", "data", "build")


def results_run(tmp_path, stream, decisions=(), name="run1"):
    """A synthetic run folder holding a results file in the slice's form."""
    run = tmp_path / "runs" / name
    run.mkdir(parents=True, exist_ok=True)
    results = {
        "schema": "verification-results",
        "schema_version": 1,
        "stream": stream,
        "run_id": name,
        "procedure_version": "1",
        "inputs": {"draft.md": "0" * 64},
        "items": [{"id": "r01", "needs_decision": True}],
        "decisions": list(decisions),
    }
    # Indented and unsorted keys, so a copy that rewrote the file would not match.
    (run / "results.json").write_text(json.dumps(results, indent=3) + "\n", encoding="utf-8")
    return run


@pytest.mark.parametrize("stream", STREAMS)
def test_results_land_under_the_streams_name_byte_for_byte(tmp_path, stream):
    run = results_run(tmp_path, stream)
    proj = project(tmp_path)
    r = call("results_to_pipeline.py", "--run", run, "--stream", stream, "--project", proj)
    assert r.returncode == 0, r.stderr
    dest = proj / "verification" / (stream + ".json")
    assert dest.read_bytes() == (run / "results.json").read_bytes()
    assert str(dest) in r.stdout
    assert sorted(tree(proj / "verification")) == [stream + ".json"]


def test_second_copy_after_a_decision_replaces_the_first(tmp_path):
    proj = project(tmp_path)
    run = results_run(tmp_path, "citations")
    assert call("results_to_pipeline.py", "--run", run, "--stream", "citations",
                "--project", proj).returncode == 0
    decision = {"item": "r01", "decision": "approved", "by": "story scholar",
                "at": "2026-10-29T10:00:00-07:00", "run_id": "run1"}
    results_run(tmp_path, "citations", decisions=[decision])
    r = call("results_to_pipeline.py", "--run", run, "--stream", "citations", "--project", proj)
    assert r.returncode == 0, r.stderr
    copied = (proj / "verification" / "citations.json").read_bytes()
    assert copied == (run / "results.json").read_bytes()
    assert b"approved" in copied


def test_results_copy_leaves_other_streams_alone(tmp_path):
    proj = project(tmp_path)
    data_run = results_run(tmp_path, "data", name="data_run")
    refs_run = results_run(tmp_path, "citations", name="refs_run")
    call("results_to_pipeline.py", "--run", data_run, "--stream", "data", "--project", proj)
    call("results_to_pipeline.py", "--run", refs_run, "--stream", "citations", "--project", proj)
    assert tree(proj / "verification") == {
        "data.json": (data_run / "results.json").read_bytes(),
        "citations.json": (refs_run / "results.json").read_bytes(),
    }


def test_stream_mismatch_is_refused_and_writes_nothing(tmp_path):
    proj = project(tmp_path)
    run = results_run(tmp_path, "data")
    r = call("results_to_pipeline.py", "--run", run, "--stream", "citations", "--project", proj)
    assert r.returncode == 2
    assert "data" in r.stderr and "citations" in r.stderr
    assert not (proj / "verification").exists()


def test_mismatch_leaves_an_older_copy_in_place(tmp_path):
    proj = project(tmp_path)
    good = results_run(tmp_path, "citations", name="good")
    call("results_to_pipeline.py", "--run", good, "--stream", "citations", "--project", proj)
    before = tree(proj)
    bad = results_run(tmp_path, "data", name="bad")
    r = call("results_to_pipeline.py", "--run", bad, "--stream", "citations", "--project", proj)
    assert r.returncode == 2
    assert tree(proj) == before


def test_run_without_results_file_is_refused(tmp_path):
    proj = project(tmp_path)
    run = tmp_path / "runs" / "stopped"
    run.mkdir(parents=True)
    (run / "manifest.json").write_text("{}\n", encoding="utf-8")
    r = call("results_to_pipeline.py", "--run", run, "--stream", "citations", "--project", proj)
    assert r.returncode == 2
    assert str(run / "results.json") in r.stderr
    assert not (proj / "verification").exists()


def test_unknown_stream_is_refused(tmp_path):
    proj = project(tmp_path)
    run = results_run(tmp_path, "selftest")
    r = call("results_to_pipeline.py", "--run", run, "--stream", "selftest", "--project", proj)
    assert r.returncode == 2
    assert "selftest" in r.stderr
    assert not (proj / "verification").exists()


def test_missing_project_is_refused_for_results(tmp_path):
    run = results_run(tmp_path, "citations")
    missing = tmp_path / "no_project"
    r = call("results_to_pipeline.py", "--run", run, "--stream", "citations", "--project", missing)
    assert r.returncode == 2
    assert str(missing) in r.stderr
    assert not missing.exists()


def test_results_file_that_is_not_json_is_refused(tmp_path):
    proj = project(tmp_path)
    run = tmp_path / "runs" / "broken"
    run.mkdir(parents=True)
    (run / "results.json").write_text("stream: citations\n", encoding="utf-8")
    r = call("results_to_pipeline.py", "--run", run, "--stream", "citations", "--project", proj)
    assert r.returncode == 2
    assert not (proj / "verification").exists()


# W9. The project-to-build copy.

BUILD_PROJECT = {
    "manuscript.md": b"# Test\n\nThis is a test manuscript.\n",
    "slides.md": b"# Slides\n\nOne slide.\n",
    "numbers.yml": b"n: {value: 3}\n",
    "Makefile": b"manuscript:\n\techo build\n",
    "audit/session_writes.jsonl": (b'{"actor": "ai", "path": "builds/manuscript/v001.md", '
                                   b'"session": "s1", "tool": "edited"}\n'),
    "audit/citation_log.yaml": b"citations: {}\n",
    "builds/manuscript/v001.md": b"This is a short test manuscript.\n",
    "builds/manuscript/BUILDS.md": b"| version |\n|---|\n| v001 |\n",
    "verification/citations.json": b"{}\n",
}


def build_project(tmp_path, drop=(), with_git=True):
    proj = tmp_path / "project"
    write_tree(proj, {k: v for k, v in BUILD_PROJECT.items() if k not in drop})
    if with_git:
        write_tree(proj / ".git", {"HEAD": b"ref: refs/heads/main\n",
                                   "objects/ab/cdef": b"\x00\x01"})
    return proj


def tar_members(path):
    import tarfile
    with tarfile.open(str(path)) as tf:
        return tf.getmembers(), {m.name: tf.extractfile(m).read() for m in tf.getmembers()
                                 if m.isfile()}


def test_packing_the_same_project_twice_gives_identical_bytes(tmp_path):
    proj = build_project(tmp_path)
    first, second = tmp_path / "inputs1", tmp_path / "inputs2"
    for to in (first, second):
        r = call("project_to_build.py", "--project", proj, "--to", to)
        assert r.returncode == 0, r.stderr
    assert (first / "project.tar").read_bytes() == (second / "project.tar").read_bytes()


def test_packing_ignores_file_times_and_modes(tmp_path):
    import os
    proj = build_project(tmp_path)
    first = tmp_path / "inputs1"
    assert call("project_to_build.py", "--project", proj, "--to", first).returncode == 0
    os.utime(str(proj / "manuscript.md"), (1700000000, 1700000000))
    os.chmod(str(proj / "slides.md"), 0o600)
    second = tmp_path / "inputs2"
    assert call("project_to_build.py", "--project", proj, "--to", second).returncode == 0
    assert (first / "project.tar").read_bytes() == (second / "project.tar").read_bytes()


def test_archive_lists_every_project_file_with_time_0_and_mode_0644_and_no_git(tmp_path):
    proj = build_project(tmp_path)
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to)
    assert r.returncode == 0, r.stderr
    members, data = tar_members(to / "project.tar")
    names = [m.name for m in members]
    assert names == sorted(BUILD_PROJECT)
    assert data == BUILD_PROJECT
    assert not [n for n in names if n == ".git" or n.startswith(".git/")]
    for m in members:
        assert m.isfile()
        assert m.mtime == 0
        assert m.mode == 0o644
        assert (m.uid, m.gid, m.uname, m.gname) == (0, 0, "", "")
    raw = (to / "project.tar").read_bytes()
    assert raw[257:265] == b"ustar\x0000"  # the USTAR magic and version, not GNU or PAX


def test_record_and_default_source_are_copied_byte_for_byte_beside_the_archive(tmp_path):
    proj = build_project(tmp_path)
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to)
    assert r.returncode == 0, r.stderr
    assert sorted(tree(to)) == ["manuscript.md", "project.tar", "session_writes.jsonl"]
    assert (to / "session_writes.jsonl").read_bytes() == BUILD_PROJECT["audit/session_writes.jsonl"]
    assert (to / "manuscript.md").read_bytes() == BUILD_PROJECT["manuscript.md"]
    assert str(to) in r.stdout


def test_two_source_options_copy_both(tmp_path):
    proj = build_project(tmp_path)
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to,
             "--source", "manuscript.md", "--source", "slides.md")
    assert r.returncode == 0, r.stderr
    assert sorted(tree(to)) == ["manuscript.md", "project.tar", "session_writes.jsonl",
                                "slides.md"]
    assert (to / "slides.md").read_bytes() == BUILD_PROJECT["slides.md"]
    assert (to / "manuscript.md").read_bytes() == BUILD_PROJECT["manuscript.md"]


def test_build_copy_leaves_the_project_unchanged(tmp_path):
    proj = build_project(tmp_path)
    before = tree(proj)
    assert call("project_to_build.py", "--project", proj, "--to", tmp_path / "inputs").returncode == 0
    assert tree(proj) == before


def test_existing_build_inputs_folder_is_refused(tmp_path):
    proj = build_project(tmp_path)
    to = tmp_path / "inputs"
    to.mkdir()
    r = call("project_to_build.py", "--project", proj, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert list(to.iterdir()) == []


def test_missing_session_writes_record_is_refused(tmp_path):
    proj = build_project(tmp_path, drop=("audit/session_writes.jsonl",))
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to)
    assert r.returncode == 2
    assert str(proj / "audit" / "session_writes.jsonl") in r.stderr
    assert not to.exists()


def test_missing_source_is_refused(tmp_path):
    proj = build_project(tmp_path)
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to,
             "--source", "manuscript.md", "--source", "paper.md")
    assert r.returncode == 2
    assert str(proj / "paper.md") in r.stderr
    assert not to.exists()


def test_every_missing_build_input_is_named(tmp_path):
    proj = build_project(tmp_path, drop=("audit/session_writes.jsonl", "manuscript.md"))
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to)
    assert r.returncode == 2
    assert str(proj / "audit" / "session_writes.jsonl") in r.stderr
    assert str(proj / "manuscript.md") in r.stderr
    assert not to.exists()


def test_two_files_landing_under_one_name_are_refused(tmp_path):
    proj = build_project(tmp_path)
    write_tree(proj, {"other/manuscript.md": b"another\n"})
    to = tmp_path / "inputs"
    r = call("project_to_build.py", "--project", proj, "--to", to,
             "--source", "manuscript.md", "--source", "other/manuscript.md")
    assert r.returncode == 2
    assert "manuscript.md" in r.stderr
    assert not to.exists()


# W12. The project-to-data copy.

DATA_TOP = {
    "pipeline.yaml": b"steps:\n  - s1_results.py\n",
    "acquisition.yaml": b"sources: []\n",
    "params.yaml": b"temperature: 0.7\n",
    "numbers.yml": b'numbers:\n  n: {value: "3", from: out.json, field: n}\n',
    "s1_results.py": b"print('results')\r\n",
    "out.json": b'{"n": 3}',
    "manuscript.md": b"# Test\n\nThis is a test manuscript.\n",
}
DATA_BELOW = {
    "builds/manuscript/v001.md": b"This is a test manuscript.\n",
    "audit/session_writes.jsonl": b'{"actor": "ai"}\n',
    "verification/data.json": b"{}\n",
    "analysis/extra.py": b"print('below')\n",
}
DECLARATIONS = ("pipeline.yaml", "acquisition.yaml", "params.yaml", "numbers.yml")


def data_project(tmp_path, drop=()):
    proj = tmp_path / "project"
    write_tree(proj, {k: v for k, v in dict(DATA_TOP, **DATA_BELOW).items() if k not in drop})
    return proj


def test_top_level_files_are_copied_byte_for_byte(tmp_path):
    proj = data_project(tmp_path)
    to = tmp_path / "inputs" / "data"
    r = call("project_to_data.py", "--project", proj, "--to", to)
    assert r.returncode == 0, r.stderr
    assert tree(to) == DATA_TOP
    assert str(to) in r.stdout


def test_nothing_under_a_subfolder_is_copied(tmp_path):
    proj = data_project(tmp_path)
    to = tmp_path / "inputs"
    assert call("project_to_data.py", "--project", proj, "--to", to).returncode == 0
    assert [p for p in to.iterdir() if p.is_dir()] == []
    for name in ("builds", "audit", "verification", "analysis"):
        assert not (to / name).exists()
    assert not set(tree(to)) & {Path(k).name for k in DATA_BELOW}


def test_data_copy_leaves_the_project_unchanged(tmp_path):
    proj = data_project(tmp_path)
    before = tree(proj)
    assert call("project_to_data.py", "--project", proj, "--to", tmp_path / "inputs").returncode == 0
    assert tree(proj) == before


def test_existing_data_inputs_folder_is_refused(tmp_path):
    proj = data_project(tmp_path)
    to = tmp_path / "inputs"
    to.mkdir()
    r = call("project_to_data.py", "--project", proj, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert list(to.iterdir()) == []


@pytest.mark.parametrize("name", DECLARATIONS)
def test_each_missing_declaration_file_is_refused(tmp_path, name):
    proj = data_project(tmp_path, drop=(name,))
    to = tmp_path / "inputs"
    r = call("project_to_data.py", "--project", proj, "--to", to)
    assert r.returncode == 2
    assert str(proj / name) in r.stderr
    for other in DECLARATIONS:
        if other != name:
            assert str(proj / other) not in r.stderr
    assert not to.exists()


def test_every_missing_declaration_file_is_named(tmp_path):
    proj = data_project(tmp_path, drop=DECLARATIONS)
    to = tmp_path / "inputs"
    r = call("project_to_data.py", "--project", proj, "--to", to)
    assert r.returncode == 2
    for name in DECLARATIONS:
        assert str(proj / name) in r.stderr
    assert not to.exists()


def test_missing_project_is_refused_for_data(tmp_path):
    to = tmp_path / "inputs"
    r = call("project_to_data.py", "--project", tmp_path / "nowhere", "--to", to)
    assert r.returncode == 2
    assert str(tmp_path / "nowhere") in r.stderr
    assert not to.exists()


# W17. The project-to-prose copy.

PROSE_PROJECT = {
    "manuscript.md": b"# Test\n\nThis is a test manuscript.\nAn added sentence.\n",
    "slides.md": b"# Slides\n\nA slide sentence.\n",
    "author_draft.md": b"# Test\n\nThis is a test manuscript.\n",
    "audit/rationales.yaml": b"- id: r01\n  anchor: \"An added sentence.\"\n  kind: insert\n",
    "audit/citation_log.yaml": b"citations: {}\n",
    "numbers.yml": b"numbers: {}\n",
}
PROSE_FOLDER = {
    "versions.yaml": b"versions:\n  - {version: author_draft, file: author_draft.md}\n",
    "author_edits.yaml": b"[]\n",
    "recorded_judge.json": b"{}\n",
    "expected_rationales.yaml": b"[]\n",
}
PROSE_COPIES = {
    "baseline.md": "author_draft.md",
    "revised.md": "manuscript.md",
    "rationales.yaml": "audit/rationales.yaml",
}


def prose_setup(tmp_path, drop_project=(), drop_prose=()):
    proj = write_tree(tmp_path / "project",
                      {k: v for k, v in PROSE_PROJECT.items() if k not in drop_project})
    prose = write_tree(tmp_path / "prose",
                       {k: v for k, v in PROSE_FOLDER.items() if k not in drop_prose})
    return proj, prose


def test_each_prose_input_lands_under_its_name_with_identical_bytes(tmp_path):
    proj, prose = prose_setup(tmp_path)
    to = tmp_path / "inputs" / "prose"
    r = call("project_to_prose.py", "--project", proj, "--prose", prose, "--to", to)
    assert r.returncode == 0, r.stderr
    assert str(to) in r.stdout
    expected = {name: PROSE_PROJECT[src] for name, src in PROSE_COPIES.items()}
    expected["versions.yaml"] = PROSE_FOLDER["versions.yaml"]
    expected["author_edits.yaml"] = PROSE_FOLDER["author_edits.yaml"]
    assert tree(to) == expected


def test_revised_carries_the_source_texts_checksum(tmp_path):
    proj, prose = prose_setup(tmp_path)
    to = tmp_path / "inputs"
    assert call("project_to_prose.py", "--project", proj, "--prose", prose,
                "--to", to).returncode == 0
    digest = hashlib.sha256((proj / "manuscript.md").read_bytes()).hexdigest()
    assert hashlib.sha256((to / "revised.md").read_bytes()).hexdigest() == digest


def test_source_option_names_the_revised_text(tmp_path):
    proj, prose = prose_setup(tmp_path)
    to = tmp_path / "inputs"
    r = call("project_to_prose.py", "--project", proj, "--prose", prose, "--to", to,
             "--source", "slides.md")
    assert r.returncode == 0, r.stderr
    assert (to / "revised.md").read_bytes() == PROSE_PROJECT["slides.md"]


def test_prose_copy_leaves_both_folders_unchanged(tmp_path):
    proj, prose = prose_setup(tmp_path)
    before = (tree(proj), tree(prose))
    assert call("project_to_prose.py", "--project", proj, "--prose", prose,
                "--to", tmp_path / "inputs").returncode == 0
    assert (tree(proj), tree(prose)) == before


def test_existing_prose_inputs_folder_is_refused(tmp_path):
    proj, prose = prose_setup(tmp_path)
    to = tmp_path / "inputs"
    to.mkdir()
    (to / "revised.md").write_bytes(b"an earlier run's text\n")
    r = call("project_to_prose.py", "--project", proj, "--prose", prose, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert tree(to) == {"revised.md": b"an earlier run's text\n"}


@pytest.mark.parametrize("name", ["manuscript.md", "author_draft.md", "audit/rationales.yaml"])
def test_each_missing_project_file_is_refused(tmp_path, name):
    proj, prose = prose_setup(tmp_path, drop_project=(name,))
    to = tmp_path / "inputs"
    r = call("project_to_prose.py", "--project", proj, "--prose", prose, "--to", to)
    assert r.returncode == 2
    assert str(proj / name) in r.stderr
    assert not to.exists()


@pytest.mark.parametrize("name", ["versions.yaml", "author_edits.yaml"])
def test_each_missing_prose_file_is_refused(tmp_path, name):
    proj, prose = prose_setup(tmp_path, drop_prose=(name,))
    to = tmp_path / "inputs"
    r = call("project_to_prose.py", "--project", proj, "--prose", prose, "--to", to)
    assert r.returncode == 2
    assert str(prose / name) in r.stderr
    assert not to.exists()


def test_every_missing_prose_input_is_named(tmp_path):
    proj, prose = prose_setup(tmp_path, drop_project=("author_draft.md", "audit/rationales.yaml"),
                              drop_prose=("versions.yaml", "author_edits.yaml"))
    to = tmp_path / "inputs"
    r = call("project_to_prose.py", "--project", proj, "--prose", prose, "--to", to,
             "--source", "missing.md")
    assert r.returncode == 2
    for path in (proj / "missing.md", proj / "author_draft.md", proj / "audit" / "rationales.yaml",
                 prose / "versions.yaml", prose / "author_edits.yaml"):
        assert str(path) in r.stderr
    assert not to.exists()


# M2. The graphs-to-knowledge-base copy.

PROCEDURE_FILES = {
    "graphs/citations.yaml": b"graph: citations\ncontracts: contracts/citations.yaml\n",
    "graphs/prose.yaml": b"graph: prose\r\ncontracts: contracts/prose.yaml\n",
    "contracts/citations.yaml": b"steps: {}\n",
    "contracts/prose.yaml": b"steps: {}\n\xe9\n",
    "registry.yaml": b"registry_version: 1\nprocedures: []\n",
}
PROCEDURE_EXTRAS = {
    "vg.py": b"print('not copied')\n",
    "README.md": b"# Procedures\n",
    "implementations/citations/check.py": b"pass\n",
    "fixtures/citations/seeded/draft.md": b"A draft.\n",
}
PROCEDURE_PARTS = ("graphs", "contracts", "registry.yaml")


def procedures_setup(tmp_path, drop=()):
    files = dict(PROCEDURE_FILES)
    files.update(PROCEDURE_EXTRAS)
    kept = {k: v for k, v in files.items()
            if k.split("/", 1)[0] not in drop and k not in drop}
    folder = tmp_path / "verification_procedures"
    folder.mkdir()
    return write_tree(folder, kept)


def test_graphs_contracts_and_registry_are_copied_byte_for_byte_and_nothing_else(tmp_path):
    procedures = procedures_setup(tmp_path)
    to = tmp_path / "kb_procedures"
    r = call("graphs_to_kb.py", "--procedures", procedures, "--to", to)
    assert r.returncode == 0, r.stderr
    assert str(to) in r.stdout
    assert tree(to) == PROCEDURE_FILES


def test_graphs_copy_leaves_the_procedures_folder_unchanged(tmp_path):
    procedures = procedures_setup(tmp_path)
    before = tree(procedures)
    assert call("graphs_to_kb.py", "--procedures", procedures,
                "--to", tmp_path / "kb_procedures").returncode == 0
    assert tree(procedures) == before


def test_existing_graphs_copy_folder_is_refused(tmp_path):
    procedures = procedures_setup(tmp_path)
    to = tmp_path / "kb_procedures"
    to.mkdir()
    r = call("graphs_to_kb.py", "--procedures", procedures, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert tree(to) == {}
    assert list(to.iterdir()) == []


@pytest.mark.parametrize("part", PROCEDURE_PARTS)
def test_each_missing_procedures_part_is_refused(tmp_path, part):
    procedures = procedures_setup(tmp_path, drop=(part,))
    to = tmp_path / "kb_procedures"
    r = call("graphs_to_kb.py", "--procedures", procedures, "--to", to)
    assert r.returncode == 2
    assert str(procedures / part) in r.stderr
    assert not to.exists()


def test_every_missing_procedures_part_is_named(tmp_path):
    procedures = procedures_setup(tmp_path, drop=PROCEDURE_PARTS)
    to = tmp_path / "kb_procedures"
    r = call("graphs_to_kb.py", "--procedures", procedures, "--to", to)
    assert r.returncode == 2
    for part in PROCEDURE_PARTS:
        assert str(procedures / part) in r.stderr
    assert not to.exists()


def test_missing_procedures_folder_is_refused(tmp_path):
    to = tmp_path / "kb_procedures"
    r = call("graphs_to_kb.py", "--procedures", tmp_path / "nowhere", "--to", to)
    assert r.returncode == 2
    assert str(tmp_path / "nowhere") in r.stderr
    assert not to.exists()


def test_the_real_procedures_folder_copies_its_three_parts_whole(tmp_path):
    procedures = ROOT / "verification_procedures"
    to = tmp_path / "kb_procedures"
    r = call("graphs_to_kb.py", "--procedures", procedures, "--to", to)
    assert r.returncode == 0, r.stderr
    expected = {name: data for name, data in tree(procedures).items()
                if name == "registry.yaml" or name.split("/", 1)[0] in ("graphs", "contracts")}
    assert expected and tree(to) == expected


# M2. The knowledge base export to the server's index file.

def test_export_lands_at_the_servers_index_file_byte_for_byte(tmp_path):
    export = record_file(tmp_path, "kb_export.json", b'{"schema": "kb-index"}\r\n\xe9')
    home = tmp_path / "connections_home"
    home.mkdir()
    dest = home / "kb_index.json"
    r = call("kb_export_to_server.py", "--export", export, "--to", dest)
    assert r.returncode == 0, r.stderr
    assert str(dest) in r.stdout
    assert dest.read_bytes() == export.read_bytes()
    assert sorted(tree(home)) == ["kb_index.json"]


def test_a_second_export_replaces_the_older_copy(tmp_path):
    first = record_file(tmp_path, "first.json", b'{"entries": [1, 2, 3]}\n')
    second = record_file(tmp_path, "second.json", b'{"entries": []}\n')
    dest = tmp_path / "kb_index.json"
    for export in (first, second):
        r = call("kb_export_to_server.py", "--export", export, "--to", dest)
        assert r.returncode == 0, r.stderr
    assert dest.read_bytes() == b'{"entries": []}\n'


def test_a_real_kb_export_is_copied_unchanged(tmp_path):
    export = tmp_path / "export.json"
    made = subprocess.run([sys.executable, "-m", "audit_layer.kb", "export", "--out", str(export)],
                          cwd=str(ROOT), capture_output=True, text=True)
    assert made.returncode == 0, made.stderr
    dest = tmp_path / "server" / "kb_index.json"
    dest.parent.mkdir()
    r = call("kb_export_to_server.py", "--export", export, "--to", dest)
    assert r.returncode == 0, r.stderr
    assert dest.read_bytes() == export.read_bytes()


def test_missing_export_file_is_refused_and_writes_nothing(tmp_path):
    dest = tmp_path / "kb_index.json"
    missing = tmp_path / "no_export.json"
    r = call("kb_export_to_server.py", "--export", missing, "--to", dest)
    assert r.returncode == 2
    assert str(missing) in r.stderr
    assert not dest.exists()


def test_missing_export_leaves_an_older_copy_in_place(tmp_path):
    dest = tmp_path / "kb_index.json"
    dest.write_bytes(b'{"older": true}\n')
    r = call("kb_export_to_server.py", "--export", tmp_path / "no_export.json", "--to", dest)
    assert r.returncode == 2
    assert dest.read_bytes() == b'{"older": true}\n'


def test_index_file_in_a_missing_folder_is_refused(tmp_path):
    export = record_file(tmp_path, "kb_export.json", b"{}\n")
    folder = tmp_path / "no_home"
    r = call("kb_export_to_server.py", "--export", export, "--to", folder / "kb_index.json")
    assert r.returncode == 2
    assert str(folder) in r.stderr
    assert not folder.exists()


def test_index_path_that_is_a_folder_is_refused(tmp_path):
    export = record_file(tmp_path, "kb_export.json", b"{}\n")
    folder = tmp_path / "kb_index.json"
    folder.mkdir()
    r = call("kb_export_to_server.py", "--export", export, "--to", folder)
    assert r.returncode == 2
    assert str(folder) in r.stderr
    assert list(folder.iterdir()) == []


# M2. The written-out project's folder into the project.

STORY = ROOT / "examples" / "test_story"
WRITTEN = {
    "written_out.yaml": b"files:\n  - path: audit/sessions.yaml\n",
    "audit/sessions.yaml": b"- id: s1\r\n",
    "audit/transcripts/claude_code/s1.jsonl": b'{"type": "user"}\n\xe9',
    "schema/field_definitions.yaml": b"fields: []\n",
}


def written_folder(tmp_path, drop=()):
    folder = tmp_path / "written"
    folder.mkdir()
    return write_tree(folder, {k: v for k, v in WRITTEN.items() if k not in drop})


def story_written_out(tmp_path):
    """Write the story project out as the audit layer does, through its command line."""
    shutil.copytree(str(STORY / "project"), str(tmp_path / "project"))
    proj = Path(os.path.realpath(str(tmp_path / "project")))
    session = tmp_path / "story_session.jsonl"
    text = (STORY / "sessions" / "claude_code" / "story_session.jsonl").read_text(encoding="utf-8")
    session.write_text(text.replace("{{PROJECT}}", str(proj)), encoding="utf-8")
    env = dict(os.environ, AUDIT_HOME=str(tmp_path / "audit_home"))
    out = tmp_path / "written"
    for args in (["init"], ["capture", "--harness", "claude_code", str(session)],
                 ["write-out", "project", "--project", str(proj), "--out", str(out)]):
        done = subprocess.run([sys.executable, "-m", "audit_layer"] + args, cwd=str(ROOT),
                              env=env, capture_output=True, text=True)
        assert done.returncode == 0, done.stderr
    return proj, out


def test_a_written_out_story_project_is_copied_whole_with_the_same_bytes(tmp_path):
    proj, written = story_written_out(tmp_path)
    to = proj / "records"
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 0, r.stderr
    assert str(to) in r.stdout
    assert "written_out.yaml" in tree(written)
    assert any(name.startswith("audit/transcripts/") for name in tree(written))
    assert tree(to) == tree(written)


def test_written_out_folder_lands_in_a_new_folder(tmp_path):
    written = written_folder(tmp_path)
    to = tmp_path / "project" / "records"
    (tmp_path / "project").mkdir()
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 0, r.stderr
    assert tree(to) == WRITTEN


def test_written_out_folder_lands_in_an_empty_folder(tmp_path):
    written = written_folder(tmp_path)
    to = tmp_path / "records"
    to.mkdir()
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 0, r.stderr
    assert tree(to) == WRITTEN


def test_writeout_copy_leaves_the_written_out_folder_unchanged(tmp_path):
    written = written_folder(tmp_path)
    assert call("writeout_to_project.py", "--from", written,
                "--to", tmp_path / "records").returncode == 0
    assert tree(written) == WRITTEN


def test_folder_without_the_write_outs_list_is_refused(tmp_path):
    written = written_folder(tmp_path, drop=("written_out.yaml",))
    to = tmp_path / "records"
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 2
    assert str(written / "written_out.yaml") in r.stderr
    assert not to.exists()


def test_missing_written_out_folder_is_refused(tmp_path):
    to = tmp_path / "records"
    r = call("writeout_to_project.py", "--from", tmp_path / "nowhere", "--to", to)
    assert r.returncode == 2
    assert str(tmp_path / "nowhere") in r.stderr
    assert not to.exists()


def test_a_target_folder_holding_anything_is_refused(tmp_path):
    written = written_folder(tmp_path)
    to = tmp_path / "records"
    (to / "audit").mkdir(parents=True)
    (to / "raw.csv").write_bytes(b"the project's raw data\n")
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert tree(to) == {"raw.csv": b"the project's raw data\n"}
    assert sorted(p.name for p in to.iterdir()) == ["audit", "raw.csv"]


def test_a_target_folder_holding_only_an_empty_folder_is_refused(tmp_path):
    written = written_folder(tmp_path)
    to = tmp_path / "records"
    (to / "audit").mkdir(parents=True)
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert tree(to) == {}


def test_a_target_that_is_a_file_is_refused(tmp_path):
    written = written_folder(tmp_path)
    to = tmp_path / "records"
    to.write_bytes(b"a file\n")
    r = call("writeout_to_project.py", "--from", written, "--to", to)
    assert r.returncode == 2
    assert str(to) in r.stderr
    assert to.read_bytes() == b"a file\n"


# P4. The session index into the project's sessions/ folder.

INDEX = {
    "sessions.csv": b"public_id,contributions\r\nS0123456789ab,1\r\n",
    "README.md": b"# Sessions\n\n| [S0123456789ab](S0123456789ab.md) |\n",
    "S0123456789ab.md": b"# Session S0123456789ab\n\xc3\xa9\n",
    "index.html": b"<!doctype html>\n<script id=\"session-data\">[]</script>\n",
}
OLDER = {
    "sessions.csv": b"public_id,contributions\r\nSffffffffffff,0\r\n",
    "README.md": b"# Sessions, an older copy\n",
    "Sffffffffffff.md": b"# Session Sffffffffffff\n",
    "index.html": b"<!doctype html>\n",
}


def index_folder(tmp_path, files=None):
    folder = tmp_path / "index"
    folder.mkdir()
    return write_tree(folder, INDEX if files is None else files)


def story_session_index(tmp_path):
    """Write the story project's session index as the audit layer does, through
    its command line."""
    shutil.copytree(str(STORY / "project"), str(tmp_path / "project"))
    proj = Path(os.path.realpath(str(tmp_path / "project")))
    env = dict(os.environ, AUDIT_HOME=str(tmp_path / "audit_home"))
    out = tmp_path / "index"
    commands = [["init"]]
    for name in ("story_session.jsonl", "build_touch_session.jsonl"):
        session = tmp_path / name
        text = (STORY / "sessions" / "claude_code" / name).read_text(encoding="utf-8")
        session.write_text(text.replace("{{PROJECT}}", str(proj)), encoding="utf-8")
        commands.append(["capture", "--harness", "claude_code", str(session)])
    commands.append(["write-out", "session-index", "--project", str(proj), "--out", str(out)])
    for args in commands:
        done = subprocess.run([sys.executable, "-m", "audit_layer"] + args, cwd=str(ROOT),
                              env=env, capture_output=True, text=True)
        assert done.returncode == 0, done.stderr
    return proj, out


def test_a_story_session_index_lands_in_the_projects_sessions_folder_byte_for_byte(tmp_path):
    proj, index = story_session_index(tmp_path)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 0, r.stderr
    assert str(proj / "sessions") in r.stdout
    names = tree(index)
    assert {"sessions.csv", "README.md", "index.html"} <= set(names)
    assert len([name for name in names if name.startswith("S") and name.endswith(".md")]) == 2
    assert tree(proj / "sessions") == names


def test_the_index_lands_in_a_new_sessions_folder(tmp_path):
    index = index_folder(tmp_path)
    proj = project(tmp_path)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 0, r.stderr
    assert tree(proj / "sessions") == INDEX
    assert tree(proj) == dict({"manuscript.md": b"A test manuscript.\n"},
                              **{"sessions/" + k: v for k, v in INDEX.items()})


def test_a_new_copy_replaces_an_older_one_whole(tmp_path):
    index = index_folder(tmp_path)
    proj = project(tmp_path)
    write_tree(proj / "sessions", OLDER)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 0, r.stderr
    assert tree(proj / "sessions") == INDEX
    assert not (proj / "sessions" / "Sffffffffffff.md").exists()


def test_the_copy_leaves_the_index_folder_unchanged(tmp_path):
    index = index_folder(tmp_path)
    proj = project(tmp_path)
    assert call("session_index_to_project.py", "--from", index,
                "--project", proj).returncode == 0
    assert tree(index) == INDEX


def test_a_missing_index_is_refused_and_writes_nothing(tmp_path):
    proj = project(tmp_path)
    r = call("session_index_to_project.py", "--from", tmp_path / "nowhere", "--project", proj)
    assert r.returncode == 2
    assert str(tmp_path / "nowhere") in r.stderr
    assert not (proj / "sessions").exists()


def test_an_empty_index_is_refused_and_writes_nothing(tmp_path):
    index = tmp_path / "index"
    index.mkdir()
    proj = project(tmp_path)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 2
    assert str(index) in r.stderr
    assert "empty" in r.stderr
    assert not (proj / "sessions").exists()


def test_a_folder_without_the_index_table_is_refused(tmp_path):
    index = index_folder(tmp_path, {k: v for k, v in INDEX.items() if k != "sessions.csv"})
    proj = project(tmp_path)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 2
    assert str(index / "sessions.csv") in r.stderr
    assert not (proj / "sessions").exists()


def test_an_index_that_is_a_file_is_refused(tmp_path):
    index = tmp_path / "index"
    index.write_bytes(b"a file\n")
    proj = project(tmp_path)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 2
    assert str(index) in r.stderr
    assert not (proj / "sessions").exists()


def test_a_refusal_leaves_an_older_copy_in_place(tmp_path):
    index = tmp_path / "index"
    index.mkdir()
    proj = project(tmp_path)
    write_tree(proj / "sessions", OLDER)
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 2
    assert "empty" in r.stderr
    assert tree(proj / "sessions") == OLDER


def test_a_missing_project_is_refused_for_the_index(tmp_path):
    index = index_folder(tmp_path)
    r = call("session_index_to_project.py", "--from", index, "--project", tmp_path / "nowhere")
    assert r.returncode == 2
    assert str(tmp_path / "nowhere") in r.stderr
    assert not (tmp_path / "nowhere").exists()


def test_a_sessions_folder_holding_no_index_is_refused(tmp_path):
    index = index_folder(tmp_path)
    proj = project(tmp_path)
    write_tree(proj / "sessions", {"notes.txt": b"the scholar's own notes\n"})
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 2
    assert str(proj / "sessions") in r.stderr
    assert tree(proj / "sessions") == {"notes.txt": b"the scholar's own notes\n"}


def test_a_sessions_path_that_is_a_file_is_refused(tmp_path):
    index = index_folder(tmp_path)
    proj = project(tmp_path)
    (proj / "sessions").write_bytes(b"a file\n")
    r = call("session_index_to_project.py", "--from", index, "--project", proj)
    assert r.returncode == 2
    assert str(proj / "sessions") in r.stderr
    assert (proj / "sessions").read_bytes() == b"a file\n"


def test_the_projects_own_copy_given_as_the_index_is_refused(tmp_path):
    proj = project(tmp_path)
    write_tree(proj / "sessions", INDEX)
    r = call("session_index_to_project.py", "--from", proj / "sessions", "--project", proj)
    assert r.returncode == 2
    assert str(proj / "sessions") in r.stderr
    assert tree(proj / "sessions") == INDEX
