"""Copy a project's files and the scholar's references folder into one inputs
folder for a run of the references procedure.

    python3 handoffs/project_to_references.py --project DIR --references DIR --to DIR
        [--source FILE]

From the project it copies the source text (FILE, manuscript.md by default) as
draft.md, author_draft.md, and audit/citation_log.yaml as citation_log.yaml. From
the references folder it copies refs.yaml, metadata_cache.json, prior_checks.json,
and every source_*.txt. Nothing else is copied, so recorded answers and expected
files kept beside the references stay out of the run. These are the files the
procedure's pin_document and pin_sources steps read.

It refuses when the --to folder already exists, since a run's inputs are fixed,
and when any of the files above is missing, naming each one. A refusal exits 2 and
writes nothing. It is a plain copy kept in handoffs/ for a scholar to replace when they
connect the layers. No layer's code calls it. Standard library only.
"""
import argparse
import glob
import os
import shutil
import sys

REFERENCE_FILES = ("refs.yaml", "metadata_cache.json", "prior_checks.json")


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="project_to_references.py",
        description="Copy a project's files into the references procedure's inputs folder.")
    parser.add_argument("--project", required=True, help="the project folder")
    parser.add_argument("--references", required=True,
                        help="the references folder the scholar keeps")
    parser.add_argument("--to", required=True, help="the inputs folder to create")
    parser.add_argument("--source", default="manuscript.md",
                        help="the source text in the project (default manuscript.md)")
    args = parser.parse_args(argv)

    if os.path.exists(args.to):
        print("the inputs folder %s already exists, and a run's inputs are fixed" % args.to,
              file=sys.stderr)
        return 2

    copies = [
        (os.path.join(args.project, args.source), "draft.md"),
        (os.path.join(args.project, "author_draft.md"), "author_draft.md"),
        (os.path.join(args.project, "audit", "citation_log.yaml"), "citation_log.yaml"),
    ]
    copies += [(os.path.join(args.references, name), name) for name in REFERENCE_FILES]
    missing = [src for src, _ in copies if not os.path.isfile(src)]
    if missing:
        for src in missing:
            print("missing %s" % src, file=sys.stderr)
        return 2
    for src in sorted(glob.glob(os.path.join(glob.escape(args.references), "source_*.txt"))):
        if os.path.isfile(src):
            copies.append((src, os.path.basename(src)))

    os.makedirs(args.to)
    for src, name in copies:
        shutil.copyfile(src, os.path.join(args.to, name))
    print(args.to)
    return 0


if __name__ == "__main__":
    sys.exit(main())
