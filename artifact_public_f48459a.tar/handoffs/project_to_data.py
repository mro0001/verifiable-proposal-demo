"""Copy a project's top-level files into one inputs folder for a run of the data
procedure.

    python3 handoffs/project_to_data.py --project DIR --to DIR

It copies every regular file at the top level of the project, byte for byte, and
nothing from its subfolders, so builds/, audit/, and verification/ stay out of the
run. The data procedure reads a flat project, as the appendix's A4 command shows by
running it on the project folder itself. The numbers file is among the copies, which
puts its checksum among the run's inputs, and that is how the build tells that a
data result is current.

It refuses when the --to folder already exists, since a run's inputs are fixed, and
when the project lacks any of pipeline.yaml, acquisition.yaml, params.yaml, and
numbers.yml, naming each one. A refusal exits 2 and writes nothing. It is a plain
copy kept in handoffs/ for a scholar to replace when they connect the layers. No
layer's code calls it. Standard library only.
"""
import argparse
import os
import shutil
import sys

DECLARATIONS = ("pipeline.yaml", "acquisition.yaml", "params.yaml", "numbers.yml")


def top_level_files(project):
    """The names of the regular files at the top of the project, sorted, leaving out
    links and folders."""
    names = []
    for name in sorted(os.listdir(project)):
        path = os.path.join(project, name)
        if os.path.isfile(path) and not os.path.islink(path):
            names.append(name)
    return names


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="project_to_data.py",
        description="Copy a project's top-level files into the data procedure's inputs folder.")
    parser.add_argument("--project", required=True, help="the project folder")
    parser.add_argument("--to", required=True, help="the inputs folder to create")
    args = parser.parse_args(argv)

    if os.path.exists(args.to):
        print("the inputs folder %s already exists, and a run's inputs are fixed" % args.to,
              file=sys.stderr)
        return 2
    if not os.path.isdir(args.project):
        print("missing project folder %s" % args.project, file=sys.stderr)
        return 2

    missing = [os.path.join(args.project, name) for name in DECLARATIONS
               if not os.path.isfile(os.path.join(args.project, name))]
    if missing:
        for path in missing:
            print("missing %s" % path, file=sys.stderr)
        return 2

    names = top_level_files(args.project)
    os.makedirs(args.to)
    for name in names:
        shutil.copyfile(os.path.join(args.project, name), os.path.join(args.to, name))
    print(args.to)
    return 0


if __name__ == "__main__":
    sys.exit(main())
