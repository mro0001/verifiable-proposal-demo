# Sample project

A small project with two research products built from one set of computed results.

- `manuscript.md`, a one-page test manuscript, built as a Word document.
- `slides.md`, a four-slide deck abbreviated from a talk on prompting, built as reveal.js slides.

Both cite the same results through placeholders such as `{{num:none.distinct}}` and `{{table:top_words}}`, and the slides also carry plain prose. The project follows the conventions of the data verification procedure, so that procedure can check every cited number against a rerun of the analysis from the raw data.

## Files

- `next_word_counts.json` is the raw data, the counts of one model's one-word answers to the same question in three conditions, 60 answers each at temperature 1.0, sampled through a university-hosted inference service on July 27, 2026. It is copied unchanged from the talk's sampling run, and `acquisition.yaml` records its checksum.
- `pipeline.yaml` declares the one analysis step, `s1_results.py`, which reads the raw data and writes `next_word_results.json`, the table `top_words.md`, and `params_record_results.csv`. `params.yaml` sets its two choices once, and `params_io.py` is the helper that reads them and writes the record.
- `numbers.yml` lists each value the manuscript and slides cite, with the output and field it comes from. The build fills each placeholder from it, and the data procedure checks each value against its rerun.
- `refs.bib` holds the one reference the manuscript cites.
- `recorded_judge.json` holds fixed answers for the data procedure's one judgment step, whether each docstring describes what its code does, so the check runs without a model. A live run asks a model instead.

## Build

Run these from this folder after the repository's install step. Nothing here uses the network or calls a model.

```
python3 s1_results.py
PYTHONPATH=../../ospipe python3 -m ospipe build --manuscript manuscript.md --manifest numbers.yml --tables-dir . --bib refs.bib --builds-dir builds/manuscript --purpose "sample manuscript"
PYTHONPATH=../../ospipe python3 -m ospipe build --manuscript slides.md --manifest numbers.yml --tables-dir . --to revealjs --builds-dir builds/slides --purpose "sample slides"
```

Each build fills every placeholder, stops if any is missing, and writes the next numbered build (`v001.docx`, then `v002.docx`, and so on) with a copy of its filled-in text and a ledger row in `BUILDS.md`. Opening the slides in a browser loads the reveal.js library from the web.

## Check the numbers

```
cd ../../verification_procedures
python3 vg.py run graphs/data.yaml --run runs/demo_sample --inputs ../examples/sample_project --judge recorded:../examples/sample_project/recorded_judge.json
```

The run reruns the analysis from the raw data in an empty folder and reports each cited number, its rerun value, and whether they agree.
