"""End to end on the test story, data stream (appendix A2.5 "Data and analysis
code", A2.3 "Verification status").

The data procedure reads no audit record, so the stream has no audit step, and
the build already reads verification/data.json against the numbers file, so it
has no pipeline step. The manuscript is built, and the project's top-level
files are handed to the data procedure, which reruns the analysis and checks
every number against the rerun, with its judgment step on the project's
recorded answers. The scholar approves every number, so the next build no
longer flags data. An edit to the manuscript leaves data unflagged, since the
data stream covers the numbers file. A change to the numbers file that keeps
every value flags data again, since any change to that file asks for a new
check.

Each layer is reached only through its command line and its files, as a
scholar would reach it, through the helpers in story_steps.py. Run from the
repository root with python3 -m pytest -q examples/test_story.
"""
import hashlib
import json

import story_steps as steps

ALL_STREAMS = {"prose", "citations", "data", "build"}
NUMBER_KEYS = ["definition.distinct", "definition.top_pct", "definition.top_word", "model",
               "n_per_condition", "none.distinct", "none.top_pct", "none.top_word", "question",
               "temperature"]
TOP_PCT_LINE = ('  none.top_pct: {value: "30.0", from: next_word_results.json, '
                'field: conditions.none.top_pct}')


def checksum(path):
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def test_data_end_to_end(tmp_path):
    project = steps.workspace(tmp_path)

    # With no results file for any stream, v001 flags all four.
    row = steps.build(project, "story v001")
    assert row["version"] == "v001"
    assert steps.flags(row) == ALL_STREAMS

    # Checked and reported. The handoff copies the project's top-level files,
    # and the data procedure runs on them with the recorded judge answers.
    inputs = tmp_path / "inputs" / "data"
    steps.handoff("project_to_data.py", "--project", str(project), "--to", str(inputs))
    assert not [p for p in inputs.iterdir() if p.is_dir()]
    run_dir = tmp_path / "runs" / "story_data"
    steps.run("graphs/data.yaml", run_dir, inputs, judge=project / "recorded_judge.json")
    records = [json.loads(p.read_text(encoding="utf-8"))
               for p in sorted((run_dir / "records").glob("*.json"))]
    assert records
    assert [r["node"] for r in records if r["checks"]["contract"] != "pass"] == []

    findings = json.loads((run_dir / "files" / "findings.json").read_text(encoding="utf-8"))
    assert [f for f in findings if f["severity"] in ("blocking", "warning")] == []

    results = json.loads((run_dir / "results.json").read_text(encoding="utf-8"))
    assert results["stream"] == "data"
    assert checksum(project / "numbers.yml") in results["inputs"].values()
    assert [item["id"] for item in results["items"]] == NUMBER_KEYS
    assert all(item["kind"] == "number" and item["findings"] == [] and item["needs_decision"]
               for item in results["items"])

    # The results reach the project, then the scholar approves every number
    # and the results are copied again.
    steps.handoff("results_to_pipeline.py", "--run", str(run_dir), "--stream", "data",
                  "--project", str(project))
    for item in results["items"]:
        steps.decide(run_dir, item["id"], approve=True)
    decided = (run_dir / "report_decided.md").read_text(encoding="utf-8")
    assert "**%d approved, 0 held, 0 undecided.**" % len(NUMBER_KEYS) in decided
    steps.handoff("results_to_pipeline.py", "--run", str(run_dir), "--stream", "data",
                  "--project", str(project))
    copied = project / "verification" / "data.json"
    assert copied.read_bytes() == (run_dir / "results.json").read_bytes()

    # Incorporated. v002 no longer flags data and names the run.
    row = steps.build(project, "story v002")
    assert row["version"] == "v002"
    assert steps.flags(row) == ALL_STREAMS - {"data"}
    assert "data=" + run_dir.name in row["runs"]

    # An edit to the manuscript leaves the numbers file as it was, so v003
    # still does not flag data.
    manuscript = project / "manuscript.md"
    text = manuscript.read_text(encoding="utf-8")
    assert text.count("This is a test manuscript.") == 1
    manuscript.write_text(text.replace("This is a test manuscript.",
                                       "This is a short test manuscript."), encoding="utf-8")
    row = steps.build(project, "story v003")
    assert row["version"] == "v003"
    assert steps.flags(row) == ALL_STREAMS - {"data"}

    # The same number written differently changes the numbers file, so v004
    # flags data again.
    numbers = project / "numbers.yml"
    text = numbers.read_text(encoding="utf-8")
    assert text.count(TOP_PCT_LINE) == 1
    numbers.write_text(text.replace(TOP_PCT_LINE, TOP_PCT_LINE.replace('"30.0"', '"30.00"')),
                       encoding="utf-8")
    row = steps.build(project, "story v004")
    assert row["version"] == "v004"
    assert steps.flags(row) == ALL_STREAMS
