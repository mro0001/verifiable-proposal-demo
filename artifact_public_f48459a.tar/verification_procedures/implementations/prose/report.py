"""report: the prose stream's fill function. Judge answers become findings, then the
step outputs fill the fields of schemas/prose.yaml (copied beside this file as
schema.yaml) with the wording the report shows, and the one report builder writes
fields.json, findings.json, and report.md.

A judge answer with honest=false or meaning_changed=true is a warning on that
change. The report lists every change between the pinned versions, AI and
author, with its rationale, verdict, and hand-off, then one Trail line per
change naming the step records that touched it.

Record numbers: every edge in graphs/prose.yaml is unconditional, so the run
order is fixed (the graph's topological order) and STEPS gives each record's
sequence number. If a conditional edge is ever added, this must change.

A change whose rationale gives its session's public id carries it in sessions, and
the report names the session on a line of its own below the Changes table.
"""
import difflib

import _lib
import _report

STEPS = ["pin_versions", "diff_changes", "exclude_author", "content_handoff",
         "rationale_coverage", "judge_rationale", "report"]
SEQ = {n: f"{i:02d}" for i, n in enumerate(STEPS, 1)}

pins = _lib.read_json("pins.json")
changes = _lib.read_json("changes.json")
author = {c["id"]: c for c in _lib.read_json("author_changes.json")}
items = {it["id"]: it for it in _lib.read_json("judge_items.json")}
answers = {a["item_id"]: a for a in _lib.read_json("judge_rationale.json")}
handoff = {h["change_id"]: h for h in _lib.read_json("handoff.json")}

jf = []
for cid in sorted(answers):
    a = answers[cid]
    honest, changed = a.get("honest") is True, a.get("meaning_changed") is True
    if honest and not changed:
        continue
    if not honest and changed:
        msg = "rationale misdescribes the change, and the change alters meaning"
    elif not honest:
        msg = "rationale misdescribes the change"
    else:
        msg = "change alters meaning beyond what the rationale says"
    jf.append(_lib.finding("judge_rationale", "warning", cid, msg,
                           "{} ({})".format(_lib.cell(a.get("reason", ""), 120), a.get("executor", ""))))
_lib.emit_findings("judge_rationale", jf)
allf = _lib.collect_findings()
by_item = {}
for f in allf:
    if f["severity"] != "info":
        by_item.setdefault(f["item"], []).append(f["check"])


def verdict(cid):
    if cid in author:
        return "author edit: listed, not judged"
    if cid not in items:
        return "SILENT: no rationale"
    a = answers.get(cid)
    if a is None:
        return "not judged (no answer)"
    if a.get("honest") is True and a.get("meaning_changed") is not True:
        return "honest"
    parts = []
    if a.get("honest") is not True:
        parts.append("rationale misdescribes")
    if a.get("meaning_changed") is True:
        parts.append("meaning changed")
    return "; ".join(parts)


def short(s, n=90):
    return _lib.cell(s, n) if s else "(none)"


def word_diff(before, after, keep=3):
    """Inline word diff, [-old-] {+new+}, with long unchanged runs elided."""
    a, b = before.split(), after.split()
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "equal":
            run = a[i1:i2]
            if len(run) > 2 * keep + 1:
                run = (run[:keep] if out else []) + ["…"] + run[-keep:]
            out += run
            continue
        if i2 > i1:
            out.append("[-" + " ".join(a[i1:i2]) + "-]")
        if j2 > j1:
            out.append("{+" + " ".join(b[j1:j2]) + "+}")
    return " ".join(out)


def what_changed(c):
    if c["kind"] == "move":
        return "(moved, text unchanged) " + short(c["after"], 70)
    if c["kind"] == "insert":
        return "{+" + short(c["after"]) + "+}"
    if c["kind"] == "delete":
        return "[-" + short(c["before"]) + "-]"
    return _lib.cell(word_diff(c["before"], c["after"]), 200)


b, r = pins["baseline"], pins["revised"]
counts = {k: sum(1 for c in changes if c["kind"] == k) for k in ("edit", "insert", "delete", "move")}
run = {"baseline_file": "{}".format(b["file"]), "baseline_version": "{}".format(b["version"] or "NOT PINNED"),
       "baseline_sha256": "{}".format(b["sha256"]),
       "revised_file": "{}".format(r["file"]), "revised_version": "{}".format(r["version"] or "(not ledgered)"),
       "revised_sha256": "{}".format(r["sha256"]),
       "n_changes": len(changes), "n_edit": counts["edit"], "n_insert": counts["insert"],
       "n_delete": counts["delete"], "n_move": counts["move"],
       "n_ai": len(changes) - len(author), "n_author": len(author),
       "n_judged": len(answers), "n_handoff": len(handoff)}


def trail_line(c):
    cid = c["id"]
    steps = ["diff_changes ({}, python3)".format(SEQ["diff_changes"])]
    if cid in author:
        steps.append("exclude_author ({}, claim {})".format(SEQ["exclude_author"], author[cid]["author_claim"]))
    else:
        steps.append("content_handoff ({}, {})".format(
            SEQ["content_handoff"], "/".join(handoff[cid]["streams"]) if cid in handoff else "no content tokens"))
        it = items.get(cid)
        steps.append("rationale_coverage ({}, {})".format(SEQ["rationale_coverage"],
                                                          it["rationale_id"] if it else "no rationale"))
        a = answers.get(cid)
        if a is not None:
            steps.append("judge_rationale ({}, {}, prompt {})".format(
                SEQ["judge_rationale"], a.get("executor", "?"), str(a.get("prompt_sha256", ""))[:19]))
    flagged = sorted(set(by_item.get(cid, [])))
    return "{}: {}{}".format(cid, " -> ".join(steps), "; flagged by " + ", ".join(flagged) if flagged else "")


def judged(cid, name):
    """The judge's answer on one change, or not run with the reason it was not judged."""
    if cid in author:
        return {"not_run": "author edit, listed not judged"}
    if cid not in items:
        return {"not_run": "no rationale to judge"}
    a = answers.get(cid)
    if a is None:
        return {"not_run": "the judge gave no answer"}
    value = a.get(name)
    return value if isinstance(value, bool) else {"not_run": "the judge's answer gave no value"}


def change_items():
    """One item for each change, giving its kind and the revised sentence (the deleted one
    for a delete) cut to 120 characters, then one item for each other group of problems. A
    change the author made needs no decision, and every other change needs one. A problem
    found on a change's own id is carried by its row."""
    attached, problems = _lib.problem_items(allf, [c["id"] for c in changes])
    rows = []
    for c in changes:
        cid = c["id"]
        text = c["before"] if c["kind"] == "delete" else c["after"]
        it = items.get(cid)
        h = handoff.get(cid)
        row = {"id": cid, "kind": "change",
               "summary": "%s: %s" % (c["kind"], text[:_lib.SUMMARY_MESSAGE_CHARS]),
               "findings": attached.get(cid, []), "needs_decision": cid not in author,
               "change_kind": c["kind"], "before": c["before"], "after": c["after"],
               "moved": bool(c.get("moved")), "by": "author" if cid in author else "ai",
               "streams": ({"not_run": "author edit, listed not judged"} if cid in author
                           else list(h["streams"]) if h else []),
               "honest": judged(cid, "honest"), "meaning_changed": judged(cid, "meaning_changed"),
               "kind_cell": c["kind"] + (" (moved)" if c.get("moved") and c["kind"] != "move" else ""),
               "change_cell": what_changed(c),
               "rationale_cell": _lib.cell("{}: {}".format(it["rationale_id"], it["rationale"]) if it
                                           else ("author" if cid in author else "(none)"), 90),
               "verdict_cell": verdict(cid),
               "handoff_cell": "/".join(h["streams"]) if h else "-",
               "trail": trail_line(c)}
        if it:
            row["rationale_id"] = it["rationale_id"]
            row["rationale"] = it["rationale"]
            if it.get("session_ref"):
                row["sessions"] = [it["session_ref"]]
                row["session_line"] = it["session_ref"]
        rows.append(row)
    return rows + problems


def handoff_rows():
    rows = []
    for cid in sorted(handoff):
        h = handoff[cid]
        diffs = "; ".join("{}: {} -> {}".format(k, ", ".join(v["removed"]) or "(none)", ", ".join(v["added"]) or "(none)")
                          for k, v in sorted(h["token_diff"].items()))
        rows.append({"change": "{}".format(cid), "streams": "/".join(h["streams"]), "token_diffs": _lib.cell(diffs, 200)})
    return rows


_report.build({"run": run, "items": change_items(), "tables": {"handoff": handoff_rows()}})
