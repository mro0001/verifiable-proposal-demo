"""report (exit): the data stream's fill function. It turns the judgments into findings,
then reads the step outputs, fills the fields of schemas/data.yaml (copied beside this file
as schema.yaml) with the wording the report shows, and hands them to the one report
builder, which writes fields.json, findings.json, and report.md.

The report opens with the summary and the problems, then four tables assembled from the
run itself, never typed: the Pipeline (does each step reproduce, are its records sound, is
its documentation sound), the Parameter record (every value each step read, from the
replayed records, against params.yaml), the Model records, and the Manuscript numbers
(typed value against replayed value).
"""
import csv
import io
import json

import _lib
import _report


def yn(ok):
    return "yes" if ok else "**no**"


def judge_findings(answers, items):
    """A judged mismatch is a warning to confirm, and an item with no usable answer is a
    warning, never dropped."""
    judged = []
    for a in answers:
        if a.get("matches") is False:
            mm = a.get("mismatches") or []
            ev = "; ".join(f"says {m.get('claim', '')!r}, code {m.get('code', '')!r}" for m in mm if isinstance(m, dict))
            judged.append(_lib.finding("judge_method_docs", "warning", a["item_id"],
                                       "documentation does not describe what the code does (judgment: confirm)",
                                       (ev or a.get("reason", "")) + f" [{a['executor']}]"))
    answered = {a["item_id"] for a in answers}
    for iid in sorted(set(items) - answered):
        judged.append(_lib.finding("judge_method_docs", "warning", iid, "no usable judgment for this item",
                                   "executor failed or answer unparseable; check by hand"))
    return judged


def number_items(numbers, findings):
    """One item for each manuscript number, giving its value, the value the rerun gave (or
    (none) when the rerun gave none), and the output it comes from, each needing a
    decision, then one item for each other group of problems. A problem found on a
    number's own key is carried by its row. A number the rerun gave no value for has its
    replayed field marked not run."""
    attached, problems = _lib.problem_items(findings, [n["key"] for n in numbers])
    rows = []
    for n in numbers:
        rerun = "(none)" if n.get("replayed") is None else n["replayed"]
        replayed = ({"not_run": "the rerun gave no value for this number"}
                    if n.get("replayed") is None else n["replayed"])
        rows.append({"id": n["key"], "kind": "number",
                     "summary": "%s = %s, rerun %s, from %s" % (n["key"], n["value"], rerun, n["from"]),
                     "findings": attached.get(n["key"], []), "needs_decision": True,
                     "key": n["key"], "value": n["value"], "replayed": replayed, "from": n["from"],
                     "ok": n["ok"], "agrees": yn(n["ok"])})
    return rows + problems


def step_rows(inv, replay, records_status, allf):
    def problems_about(check, pred):
        return [x for x in allf if x["check"] == check and x["severity"] != "info" and pred(x["item"])]

    by_step = {s["id"]: s for s in replay["steps"]}
    rows = []
    for s in inv["steps"]:
        r = by_step.get(s["id"], {})
        outs = r.get("outputs", [])
        repro = bool(outs) and all(o["reproduces"] for o in outs) and r.get("exit_code") == 0
        stem = s["script"].rsplit(".", 1)[0]
        docs = not problems_about("check_docs", lambda i, sc=s["script"]: i == sc or i.startswith(sc + ":")) \
            and not problems_about("judge_method_docs", lambda i, st=stem: i == st or i.startswith(st + ".")) \
            and not problems_about("check_params", lambda i, sc=s["script"]: i.startswith(sc + ":"))
        bad = [o["file"] for o in outs if not o["reproduces"]]
        rows.append({"step": "{}".format(s["id"]), "script": "{}".format(s["script"]),
                     "reproduces": yn(repro) + (f" ({', '.join(bad)})" if bad else ""),
                     "records_ok": yn(records_status.get(s["id"], True)), "docs_ok": yn(docs),
                     "stderr": "warning" if (r.get("stderr") or "").strip() else "clean"})
    return rows


def param_rows(inv, replay, params):
    rows = []
    recorded = set()
    for s in inv["steps"]:
        text = replay["replayed"].get(f"params_record_{s['id']}.csv")
        if not text:
            continue
        for r in csv.DictReader(io.StringIO(text)):
            recorded.add(r["param"])
            want = params.get(r["param"])
            rows.append({"param": "{}".format(r["param"]), "recorded": _lib.cell(r["value"]),
                         "params_yaml": _lib.cell(want), "agrees": yn(str(want) == r["value"]),
                         "step": "{}".format(r["step"]), "script": "{}".format(r["script"])})
    for k in sorted(set(params) - recorded):
        rows.append({"param": "{}".format(k), "recorded": "(not read by any step)",
                     "params_yaml": _lib.cell(params[k]), "agrees": "n/a", "step": "", "script": ""})
    return rows


def model_rows(inv, replay, proj):
    rows = []
    current = proj["files"].get("params.yaml", {}).get("sha256")
    for s in inv["steps"]:
        name = f"model_record_{s['id']}.json"
        if name not in proj["files"]:
            continue
        try:
            rec = json.loads(proj["files"][name]["text"])
        except (KeyError, ValueError):
            continue
        rep = next((o["reproduces"] for st in replay["steps"] for o in st["outputs"] if o["file"] == name), False)
        rows.append({"record": name, "model": "{}".format(rec.get("model")), "spec": _lib.cell(rec.get("spec")),
                     "n": "{}".format(rec.get("n")), "current": yn(rec.get("params_sha256") == current),
                     "reproduces": yn(rep)})
    return rows


def main():
    proj = _lib.read_json("project.json")
    inv = _lib.read_json("inventory.json")
    replay = _lib.read_json("replay.json")
    records_status = {r["step"]: r["records_ok"] for r in _lib.read_json("records_status.json")}
    numbers = _lib.read_json("numbers_check.json")
    answers = _lib.read_json("judge_method_docs.json")
    items = {i["id"]: i for i in _lib.read_json("method_items.json")}

    _lib.emit_findings("judge_method_docs", judge_findings(answers, items))
    allf = _lib.collect_findings()
    run = {"n_steps": inv["n_steps"], "n_raw": len(inv["raw"]), "n_numbers": inv["n_numbers"],
           "n_method_items": len(items),
           "n_step_items": sum(1 for i in items.values() if i["kind"] == "step"),
           "n_function_items": sum(1 for i in items.values() if i["kind"] == "function"),
           "n_mismatch": sum(1 for a in answers if a.get("matches") is False)}
    _report.build({
        "run": run,
        "items": number_items(numbers, allf),
        "tables": {"steps": step_rows(inv, replay, records_status, allf),
                   "params": param_rows(inv, replay, proj["params"]),
                   "models": model_rows(inv, replay, proj)},
    })


if __name__ == "__main__":
    main()
