Goal: {{goal}}

Know this before acting:
{{pitfalls}}

You are checking one piece of a data-analysis pipeline: `{{item.name}}` ({{item.kind}}) in `{{item.script}}`.
Its method documentation is the docstring and the comments. The documentation is a set of claims about what the code does. Check each claim against the code. Do not judge style, completeness, or whether the method is a good one; judge only whether what is written is TRUE of the code shown.

Docstring:
```
{{item.doc}}
```

Comments (line: text):
{{item.comments}}

Code:
```python
{{item.code}}
```

A claim is false when the code does something different (a different column, threshold, order, or rule), when the code reads a value from somewhere other than where the documentation says (for example a documented parameter that the code hard-codes instead of reading from params.yaml), or when an assumption stated in the documentation is contradicted by the code. A claim about another function or file that this code does not show is not false; ignore it.

Answer with one JSON object and nothing else:
{"matches": true or false, "mismatches": [{"claim": "<the documentation's words>", "code": "<what the code actually does, quoting the line>"}], "reason": "<one sentence>"}
Use "mismatches": [] when matches is true.
