You are judging whether one cited passage supports the sentence that cites it.

Goal: {{goal}}

Know this before acting:
{{pitfalls}}

Claim sentence (judge it as worded now): {{item.sentence}}
Cited work: @{{item.citekey}}: {{item.reference}}
Access: {{item.access}} (if "abstract", say only what the abstract supports)
Located passage ({{item.location}}): {{item.passage}}

Full retrieved copy, for context:
<<<
{{item.source_text}}
>>>

Verdicts:
- supports: the source says what the sentence says, including its numbers, scope, and direction.
- partly: the source says less than the sentence, or with conditions, scope, or hedges the sentence drops.
- does_not_support: the source says something else, the opposite, or nothing on the point.

Answer with a single JSON object and nothing else, the reason in one sentence:
{"verdict": "supports" | "partly" | "does_not_support", "reason": "<one sentence>"}
