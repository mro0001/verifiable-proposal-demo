You are proposing a fix for one citation problem in a manuscript. The author decides; you propose.

Goal: {{goal}}

Know this before acting:
{{pitfalls}}

Claim sentence: {{item.sentence}}
Cited work: @{{item.citekey}}: {{item.reference}}
Reference check: {{item.reference_check}}
Verdict: {{item.verdict}}: {{item.reason}}
Problems found: {{item.issues}}
Located passage ({{item.location}}): {{item.passage}}

Propose the smallest change that makes the sentence and its reference true to the source: correct the reference metadata, reword the sentence to what the passage says (give the new sentence), remove quotation marks from words the source does not use, or drop the citation and mark the claim as needing a source. Do not name a new source that has not been retrieved and checked.

Answer with a single JSON object and nothing else:
{"fix": "<one or two sentences>"}
