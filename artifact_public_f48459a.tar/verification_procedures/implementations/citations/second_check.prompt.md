You are the independent second checker for one citation. A first checker judged that the source does not fully support the sentence. Read the source yourself first, decide, and only then compare.

Goal: {{goal}}

Know this before acting:
{{pitfalls}}

Claim sentence (judge it as worded now): {{item.sentence}}
Cited work: @{{item.citekey}}: {{item.reference}}
Access: {{item.access}}
Passage the first checker located ({{item.location}}): {{item.passage}}

Full retrieved copy:
<<<
{{item.source_text}}
>>>

First checker's verdict: {{item.verdict}}, because: {{item.reason}}

Verdicts: supports / partly / does_not_support (same meanings as for the first checker: partly = the source says less or with conditions the sentence drops; does_not_support = it says something else, the opposite, or nothing).

Answer with a single JSON object and nothing else; agree is true only if your own verdict equals the first checker's:
{"agree": true | false, "verdict": "supports" | "partly" | "does_not_support", "reason": "<one sentence>"}
