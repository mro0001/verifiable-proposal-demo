You are checking one citation in a manuscript against the retrieved copy of the work it cites.

Goal: {{goal}}

Know this before acting:
{{pitfalls}}

Claim sentence (as it reads now): {{item.sentence}}
Cited work: @{{item.citekey}}: {{item.reference}}
Locator given in the draft: {{item.locator}}
Access: {{item.access}} (if "abstract", only the abstract was retrieved)

Retrieved copy:
<<<
{{item.source_text}}
>>>

Task: find the passage in the retrieved copy that bears most directly on the claim, whether it supports the claim or not.
- Copy it EXACTLY as it appears, character for character, one to three sentences. Do not paraphrase, shorten inside a sentence, or fix wording.
- location: the nearest page marker (e.g. "p. 12") or section heading before the passage; "" if there is none.
- If nothing in the retrieved copy bears on the claim, set found to false and quote to "".

Answer with a single JSON object and nothing else:
{"quote": "<exact passage>", "location": "<page or section>", "found": true}
