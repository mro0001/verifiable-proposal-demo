"""report: the citations stream's fill function. The step outputs fill the fields of
schemas/citations.yaml (copied beside this file as schema.yaml) with the wording the
report shows, and the one report builder writes fields.json, findings.json, and
report.md. The report gives counts first (verified / problems / couldn't check /
author's warrant), problems first, then every row: claim, reference, passage +
location, verdict + reason, access, proposed fix, origin, trail (who checked, which
retrieved copy, which records). An AI contribution whose citation-log entry gives the
session's public id also shows it on a Session line, and its item carries it in
sessions.

A blocking finding of extract_citations, on a draft whose citations the check
cannot read, is an item of its own that needs a decision, so the stream cannot
read as verified (Track L, Step L5). It is listed under Problems and is not
counted among the citation rows."""
import _lib
import _report

# Step order as the runtime walks graphs/citations.yaml (topological order).
# Which settle node ran depends on whether any verdict needed a second check.
BEFORE = ["pin_document", "extract_citations", "attribute_origin", "match_references", "fetch_metadata",
          "check_existence", "pin_sources", "reuse_prior", "check_access", "locate_passage",
          "verify_quote", "judge_support", "collect_verdicts"]
AFTER_SECOND = ["second_check", "settle_verdicts", "draft_fix", "record_verdicts", "report"]
AFTER_NONE = ["settle_unanimous", "draft_fix", "record_verdicts", "report"]

ORIGIN = {
    "yours": "yours (author's source, author's sentence)",
    "ai_added": "ai_added (AI introduced the source)",
    "ai_reworded": "ai_reworded (author's source, AI rewrote the sentence)",
    "ai_sourced_author_worded": "ai_sourced_author_worded (AI suggested the source; author reworded or moved the sentence)",
    "unknown": "unknown (no log entry; checked as if AI)",
}
VERDICT = {"supports": "supports", "partly": "partly supports", "does_not_support": "does not support",
           "not_checked": "not checked"}
ACCESS = {"fulltext": "full text", "abstract": "abstract only", "none": "no retrieved copy"}

rows = _lib.read_json("rows_final.json")
tally = _lib.read_json("verdict_tally.json")
pin = _lib.read_json("doc_pin.json")

order = BEFORE + (AFTER_SECOND if tally["to_recheck"] > 0 else AFTER_NONE)
seq = {node: "%02d_%s" % (i + 1, node) for i, node in enumerate(order)}


def short(h):
    return h[:19] + "..." if h else ""


def trail(r):
    parts = []
    if r["status"] == "checking":
        parts.append("passage located by %s (record %s), checked mechanically (record %s), verdict by %s (record %s)"
                     % (r.get("locate_executor") or "?", seq["locate_passage"], seq["verify_quote"],
                        r.get("judge_executor") or "?", seq["judge_support"]))
        if r.get("second_executor"):
            parts.append("second check by %s (record %s)" % (r["second_executor"], seq["second_check"]))
    elif r["status"] == "reused":
        p = r.get("prior", {})
        parts.append("verdict carried over from the check by %s on %s (record %s)"
                     % (p.get("checked_by", "?"), p.get("checked_on", "?"), seq["reuse_prior"]))
    if r["citekey"] and r["status"] != "author":
        parts.append("reference checked (records %s, %s)" % (seq["fetch_metadata"], seq["check_existence"]))
    if r.get("source_file"):
        parts.append("retrieved copy %s %s" % (r["source_file"], short(r.get("source_sha256", ""))))
    if r.get("fix_executor"):
        parts.append("fix proposed by %s (record %s)" % (r["fix_executor"], seq["draft_fix"]))
    parts.append("times: each record's started_at")
    return "; ".join(parts)


def verdict_text(r):
    verdict = VERDICT.get(r["verdict"], r["verdict"])
    if r.get("access") == "abstract" and r["verdict"] != "not_checked":
        verdict += " (abstract only)"
    if r.get("disputed"):
        verdict += "; second checker says %s" % VERDICT.get(r["second_verdict"], r["second_verdict"] or "nothing")
    elif r.get("second_verdict"):
        verdict += "; second checker agrees"
    return verdict


def passage_line(r):
    if r.get("passage"):
        return "\"%s\" (%s)" % (r["passage"], r.get("location") or "location not given")
    if r["status"] in ("checking", "reused"):
        return "none located"
    return ""


# The origins of a citation an AI session introduced, whose log entry names that session.
AI_INTRODUCED = ("ai_added", "ai_sourced_author_worded")


def session_fields(r):
    """sessions, and session_line, its text for the report, for a row an AI session
    introduced whose log entry gives the session's public id, else nothing."""
    ref = r.get("introduced_session_ref")
    if not ref or r["origin"] not in AI_INTRODUCED:
        return {}
    return {"sessions": [ref], "session_line": ref}


def item(r):
    """One row's fields: what the steps found, under the row's names in rows_final.json,
    then the lines of its block in the report."""
    verdict = verdict_text(r)
    reason = r.get("reason", "")
    issues = "; ".join(r.get("issues") or [])
    problem = r["category"] == "problem"
    return dict({
        "id": r["id"], "citekey": r["citekey"], "sentence": r["sentence"], "origin": r["origin"],
        "moved": r["moved"], "status": r["status"], "category": r["category"], "access": r["access"],
        "reference": r["reference"], "reference_check": r["reference_check"], "passage": r["passage"],
        "location": r["location"], "verdict": r["verdict"], "reason": r["reason"], "fix": r["fix"],
        "source_file": r["source_file"], "source_sha256": r["source_sha256"],
        "second_verdict": r["second_verdict"], "second_reason": r["second_reason"],
        "disputed": r["disputed"], "issues": list(r["issues"]),
        "needs_decision": r["category"] != "author",
        "heading": "%s: %s, @%s" % (r["id"], verdict, r["citekey"]),
        "reference_line": "%s Check: %s." % (r.get("reference", ""), r.get("reference_check", "").rstrip(".")),
        "passage_line": passage_line(r),
        "verdict_line": "%s. %s" % (verdict, reason[:1].upper() + reason[1:]),
        "access_line": ACCESS.get(r.get("access", "none"), r.get("access", "")),
        "problems_line": issues if problem else "",
        "flags_line": "" if problem else issues,
        "fix_line": (r.get("fix") or "none proposed") if problem else "",
        "origin_line": "%s%s" % (ORIGIN.get(r["origin"], r["origin"]),
                                 "; sentence moved, text unchanged" if r.get("moved") else ""),
        "trail": trail(r),
        "warrant_line": "%s, @%s: %s%s" % (r["id"], r["citekey"], r["sentence"],
                                           " (moved, text unchanged)" if r.get("moved") else ""),
    }, **session_fields(r))


def unread_item(f):
    """The item for a blocking finding of extract_citations, with the row fields every
    item carries, filled for a draft whose citations were not read."""
    message = f["message"]
    return {
        "id": f["item"], "citekey": "", "sentence": f.get("evidence", ""), "origin": "unknown",
        "moved": False, "status": "not_checked", "category": "problem", "access": "none",
        "reference": "", "reference_check": "not checked", "passage": "", "location": "",
        "verdict": "not_checked", "reason": message, "fix": "", "source_file": "", "source_sha256": "",
        "second_verdict": "", "second_reason": "", "disputed": False, "issues": [message],
        "needs_decision": True,
        "heading": "%s: citations not read" % f["item"],
        "reference_line": "No reference checked, since no citation key was read.",
        "passage_line": "",
        "verdict_line": "%s. %s" % (VERDICT["not_checked"], message[:1].upper() + message[1:]),
        "access_line": ACCESS["none"],
        "problems_line": message, "flags_line": "", "fix_line": "",
        "origin_line": "unknown, since no citation key was read",
        "trail": "found by extract_citations (record %s); times: each record's started_at" % seq["extract_citations"],
        "warrant_line": "",
    }


unread = [f for f in _lib.read_json("findings_extract_citations.json") if f["severity"] == "blocking"]

counts = {k: sum(1 for r in rows if r["category"] == k) for k in ("problem", "not_checked", "verified", "author")}
run = {"draft_sha256": pin["draft_sha256"], "n_rows": len(rows), "n_verified": counts["verified"],
       "n_problem": counts["problem"], "n_not_checked": counts["not_checked"], "n_author": counts["author"],
       "n_abstract_verified": sum(1 for r in rows if r["category"] == "verified" and r.get("access") == "abstract"),
       "n_reused": sum(1 for r in rows if r["status"] == "reused")}

_report.build({"run": run, "items": [item(r) for r in rows] + [unread_item(f) for f in unread],
               "tables": {}})
