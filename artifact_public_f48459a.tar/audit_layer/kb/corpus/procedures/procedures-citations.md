---
id: procedures-citations
title: Source support
source: verification_procedures/graphs/citations.yaml
source_commit: sha256:6f313de776dd
updated: 2026-10-29
group: PROCEDURES
---

# Source support

Check every AI-contributed citation in the draft against its source, so the author can read one report and confirm any verdict without redoing the work. The procedural graph system runs it with the command below, so a session finds it here and does not carry out its steps by hand.

1. Purpose. Check every AI-contributed citation in the draft against its source, so the author can read one report and confirm any verdict without redoing the work. Two questions per citation: (1) is the cited work real and described correctly; (2) does the cited passage support the sentence that cites it. Citations the author introduced, in sentences the author wrote, are listed as the author's warrant and not checked.
2. Triggers. It starts on the harness events `ai_edit`, `turn_end`, `build`, and `commit`. It starts on a request that uses the phrase "verify citations", "check references", or "citation report".
3. Steps. 19 steps, in the order the runtime runs them, each only when a transition into it fires.
   - `pin_document` (tool step) Hash the draft and every fixed input so the report names exactly what was checked.
   - `extract_citations` (tool step) One row per (citekey, sentence): sentence text, its normalized hash, locator, quoted phrases, numbers.
   - `attribute_origin` (tool step) Label each row yours / ai_added / ai_reworded / ai_sourced_author_worded / unknown by matching sentences to the author's last draft by normalized text; only AI-contributed rows go on to be checked.
   - `match_references` (tool step) Every cited key has a reference-list entry; uncited entries are noted.
   - `fetch_metadata` (tool step) Look up each checked reference's DOI (cache first, Crossref live unless VG_OFFLINE=1).
   - `check_existence` (tool step) Compare the reference entry with the looked-up record (exists, surnames, initials, year, title, venue, stage).
   - `pin_sources` (tool step) Pin the retrieved copies (source_<citekey>.txt): access level, sha256, text. Each copy is a hashed input, so every later verdict names the copy it read.
   - `reuse_prior` (tool step) Carry over an earlier verdict only when the sentence and the retrieved copy are both unchanged.
   - `check_access` (tool step) Per row: full text, abstract only, or no copy; rows with no copy are marked not checked.
   - `locate_passage` (judgment step, once per item in `rows_access.json` where status in [checking]) Find and copy verbatim the passage in the retrieved copy that bears on the claim.
   - `verify_quote` (tool step) Mechanical checks: the located passage, every quoted phrase in the claim, and every number in the claim must appear in the retrieved copy.
   - `judge_support` (judgment step, once per item in `rows_quoted.json` where status in [checking]) Does the passage support the claim as worded: supports, partly, or does_not_support.
   - `collect_verdicts` (tool step) Join verdicts with every earlier finding per row; mark problem rows and rows to recheck; count them.
   - `second_check` (judgment step by the second checker, once per item in `rows_judged.json` where recheck in [true]) An independent model rechecks every verdict that is not supports.
   - `settle_unanimous` (tool step) No verdict needed a second check; carry rows forward unchanged.
   - `settle_verdicts` (tool step) Record the second check beside the first; disagreement marks the row disputed.
   - `draft_fix` (judgment step, once per item in `rows_settled.json` where problem in [true]) Propose the smallest fix for each problem row.
   - `record_verdicts` (tool step) Turn verdicts and second checks into findings; attach fixes to rows.
   - `report` (tool step) Write findings.json and report.md: counts first, problems first, then every row with origin and trail.
4. Run command. From the `verification_procedures` folder, run `python3 vg.py run graphs/citations.yaml --run runs/<new run folder> --inputs <inputs folder> --judge <executor> --second <executor>`. The inputs folder holds `author_draft.md`, `citation_log.yaml`, `draft.md`, `metadata_cache.json`, `prior_checks.json`, and `refs.yaml`, and any files matching `source_*.txt`. An executor is `recorded:<answers file>` or a model the runtime can reach.
5. Version. Graph version 0.1, 19 steps and 19 transitions, checked with `python3 vg.py check graphs/citations.yaml`.

## Consult also

- guidelines-authoring-procedures - to write a new procedure or revise this one.
