---
id: procedures-data
title: Code
source: verification_procedures/graphs/data.yaml
source_commit: sha256:0c73f2d272c9
updated: 2026-10-29
group: PROCEDURES
---

# Code

Show that every table, figure, model record, and manuscript number is the product of the declared pipeline run from unchanged raw data with parameters set once in params.yaml, that the parameter and model records were written by that run, and that each method step's documentation says what its code does. The procedural graph system runs it with the command below, so a session finds it here and does not carry out its steps by hand.

1. Purpose. Show that every table, figure, model record, and manuscript number is the product of the declared pipeline run from unchanged raw data with parameters set once in params.yaml, that the parameter and model records were written by that run, and that each method step's documentation says what its code does.
2. Triggers. It starts on the harness events `ai_edit`, `turn_end`, `build`, and `commit`. It starts on a request that uses the phrase "verify data", "check the analysis", or "rerun the analysis".
3. Steps. 9 steps, in the order the runtime runs them, each only when a transition into it fires.
   - `inventory` (tool step) Parse pipeline.yaml; check every declared file exists, inputs come from raw or earlier steps; bundle the project into project.json.
   - `check_raw` (tool step) Compare each raw file with its acquisition hash; a raw input without an acquisition record is blocking.
   - `check_params` (tool step) AST scan: literals that equal a params value or act as thresholds/settings without coming from params.yaml; unused and unknown params.
   - `replay_pipeline` (tool step) Run every step from raw in an empty folder; compare each output byte for byte with the committed copy; read stderr.
   - `check_docs` (tool step) Docstring sections present; Inputs/Outputs agree with pipeline.yaml; Parameters agree with what the script reads; functions documented. Emits the method items to judge.
   - `check_records` (tool step) Parameter and model records exist, equal params.yaml, equal the replay, and were made under the current params.yaml.
   - `check_numbers` (tool step) Each numbers.yml value equals the replayed output it names.
   - `judge_method_docs` (judgment step, once per item in `method_items.json`) Per script and per function: does the docstring and comment text describe what the code actually does?
   - `report` (tool step) Turn judgments into findings; write findings.json and report.md with Pipeline, Parameter record, Model records, and Manuscript numbers tables.
4. Run command. From the `verification_procedures` folder, run `python3 vg.py run graphs/data.yaml --run runs/<new run folder> --inputs <inputs folder> --judge <executor>`. The inputs folder holds `acquisition.yaml`, `numbers.yml`, `params.yaml`, and `pipeline.yaml`, and any files matching `*`. An executor is `recorded:<answers file>` or a model the runtime can reach.
5. Version. Graph version 0.1, 9 steps and 12 transitions, checked with `python3 vg.py check graphs/data.yaml`.

## Consult also

- guidelines-authoring-procedures - to write a new procedure or revise this one.
