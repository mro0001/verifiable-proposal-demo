---
id: procedures-prose
title: Change review
source: verification_procedures/graphs/prose.yaml
source_commit: sha256:2bff21c9398e
updated: 2026-10-29
group: PROCEDURES
---

# Change review

Every AI change between two pinned drafts is visible, carries a rationale that honestly describes it, and any change to numbers, citations, quoted text, negation, or claim strength is handed to the citations or data stream instead of passing as style. The procedural graph system runs it with the command below, so a session finds it here and does not carry out its steps by hand.

1. Purpose. Every AI change between two pinned drafts is visible, carries a rationale that honestly describes it, and any change to numbers, citations, quoted text, negation, or claim strength is handed to the citations or data stream instead of passing as style. Author edits are listed, not judged.
2. Triggers. It starts on the harness events `ai_edit`, `turn_end`, `build`, and `commit`. It starts on a request that uses the phrase "verify prose", "check AI edits", or "change review".
3. Steps. 7 steps, in the order the runtime runs them, each only when a transition into it fires.
   - `pin_versions` (tool step) Hash baseline and revised; the baseline must match a ledgered version in versions.yaml.
   - `diff_changes` (tool step) Align sentences of baseline and revised; emit edits, inserts, deletes, and moves with deterministic ids.
   - `exclude_author` (tool step) Set aside the changes listed in author_edits.yaml; the rest are AI changes.
   - `content_handoff` (tool step) Flag AI changes that alter numbers, citation keys, quoted passages, negation, or hedge/booster strength; write handoff.json for the other streams.
   - `rationale_coverage` (tool step) Bind rationales to AI changes; flag silent changes, claimed changes not made, and kind mismatches.
   - `judge_rationale` (judgment step, once per item in `judge_items.json`) Per rationalized AI change, judge whether the rationale honestly describes it and whether meaning changed beyond it.
   - `report` (tool step) Turn judge answers into findings; write findings.json and report.md with a Changes table and a Trail line per change.
4. Run command. From the `verification_procedures` folder, run `python3 vg.py run graphs/prose.yaml --run runs/<new run folder> --inputs <inputs folder> --judge <executor>`. The inputs folder holds `author_edits.yaml`, `baseline.md`, `rationales.yaml`, `revised.md`, and `versions.yaml`. An executor is `recorded:<answers file>` or a model the runtime can reach.
5. Version. Graph version 0.2, 7 steps and 6 transitions, checked with `python3 vg.py check graphs/prose.yaml`.

## Consult also

- guidelines-authoring-procedures - to write a new procedure or revise this one.
