"""The Word adapter, which turns a reviewed Word document into the prose stream's input files (Track D, step D19).

Appendix-only. Table A6 lists an adapter for Word as specified, and its note
says the adapter that fills the prose stream's files is not built. A2.5 Prose
says that for Word, programs show AI changes as tracked changes and then read
back the scholar's responses, and the A2.2 Adapters bullet names an adapter
from a Word document with tracked changes to the files the prose procedure
checks. It reads the document with the Word reader (step D18).

python3 -m connections adapt word --out DIR --docx FILE --ai-author NAME
[--annotations FILE] [--builds-dir DIR --baseline-version vNNN] writes five
files.

- baseline.md and revised.md, the document's text with every tracked change
  rejected and with every one accepted, as side_text writes them.
- rationales.yaml, the AI author's margin comments in the order the document
  lists them, each as {id: rNN, anchor, kind, rationale}. The anchor is the
  revised sentence holding the first character the comment covers, or the
  baseline sentence when it covers only deleted text. The kind is the leading
  [edit], [insert], [delete], or [move] tag, empty when there is none, and the
  rationale is the rest (Track D choice 14). The adapter copies the kind and
  never infers it. Other authors' comments are left out. With --annotations,
  the YAML list annotate read (anchor, text, tag) gives the rationales in its
  order instead, each read as the comment annotate writes from it.
- author_edits.yaml, {id: aNN, anchor, note: tracked change by <author>} for
  each sentence holding a tracked change by another author, or [].
- versions.yaml. With --builds-dir and --baseline-version it finds the
  version's row in BUILDS.md by the ledger's header names and checks
  <version>.docx against the row's sha256. When they match it pins that build,
  with the sha256 of the build's text as side_text writes it. Otherwise, and
  without the options, it writes versions: [] and prints why, and the prose
  procedure reports the diff as unanchored (Track D choice 15).

sentences(text) is the prose procedure's sentence rule, copied here because
connections imports no verification code. A sentence ends at ., ?, or !,
keeping a closing quotation mark, before a space and a capital letter, a
quotation mark, or a bracket.
"""
import hashlib
import re
from pathlib import Path

import yaml

from connections.adapters import ADAPTERS, Adapter, AdapterError
from connections.adapters.docx_text import DocxError, read_docx, side_text

FILLS = ("baseline.md", "revised.md", "rationales.yaml", "author_edits.yaml", "versions.yaml")
LEDGER = "BUILDS.md"

# The prose procedure's sentence rule, _lib.sentences plus diff_changes' split
# after a sentence that ends inside a closing quote.
FRONT_MATTER = re.compile(r"^---\n.*?\n---\n", re.S)
PARAGRAPH = re.compile(r"\n\s*\n")
SENTENCE_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"(\[])")
CLOSE_QUOTE_END = re.compile(r'(?<=[.!?]["”\'’])\s+(?=[A-Z"“(\[])')
SPACE = re.compile(r"\s+")

KIND_TAG = re.compile(r"\s*\[(edit|insert|delete|move)\]")


def sentences(text: str) -> list:
    """The sentences of a markdown text, in order, as the prose procedure splits them."""
    body = FRONT_MATTER.sub("", text)
    out = []
    for para in PARAGRAPH.split(body):
        para = para.strip()
        if not para or para.startswith("#"):
            continue
        para = SPACE.sub(" ", para)
        for s in SENTENCE_END.split(para):
            if s.strip():
                out.extend(p for p in CLOSE_QUOTE_END.split(s.strip()) if p.strip())
    return out


def add_arguments(parser) -> None:
    parser.add_argument("--docx", required=True, metavar="FILE", help="the reviewed Word document")
    parser.add_argument(
        "--ai-author", required=True, metavar="NAME",
        help="the author name the AI's tracked changes and comments carry",
    )
    parser.add_argument(
        "--annotations", metavar="FILE",
        help="the YAML list annotate read, which gives the rationales instead of the comments",
    )
    parser.add_argument("--builds-dir", metavar="DIR", help="the build folder holding BUILDS.md")
    parser.add_argument(
        "--baseline-version", metavar="vNNN", help="the ledgered build the baseline should match",
    )


# ---------------------------------------------------------------- sentences in one paragraph

def _pieces(text: str, start: int, end: int, pattern) -> list:
    """The spans of text[start:end] between the matches of pattern."""
    chunk = text[start:end]
    spans, last = [], 0
    for match in pattern.finditer(chunk):
        spans.append((start + last, start + match.start()))
        last = match.end()
    spans.append((start + last, end))
    return spans


def _spans(paragraph: dict, side: str) -> list:
    """Each sentence of one paragraph on one side, as (start, end, sentence), split as sentences() splits."""
    text = paragraph[side]
    if paragraph["level"]:
        stripped = text.strip()
        if not stripped:
            return []
        start = len(text) - len(text.lstrip())
        return [(start, start + len(stripped), SPACE.sub(" ", stripped))]
    out = []
    for a, b in _pieces(text, 0, len(text), PARAGRAPH):
        chunk = text[a:b].strip()
        if not chunk or chunk.startswith("#"):
            continue
        for s0, s1 in _pieces(text, a, b, SENTENCE_END):
            for p0, p1 in _pieces(text, s0, s1, CLOSE_QUOTE_END):
                while p0 < p1 and text[p0].isspace():
                    p0 += 1
                while p1 > p0 and text[p1 - 1].isspace():
                    p1 -= 1
                if p0 < p1:
                    out.append((p0, p1, SPACE.sub(" ", text[p0:p1])))
    return out


def _sentence_at(doc: dict, side: str, index: int, offset: int):
    """The span of the sentence holding character offset of paragraph index on side, or None."""
    for span in _spans(doc["paragraphs"][index], side):
        if span[0] <= offset < span[1]:
            return span
    return None


def _first_character(doc: dict, side: str, start, end):
    """The first character that is not a space between start and end on side, as (paragraph, offset), or None."""
    (p0, o0), (p1, o1) = start, end
    for index in range(p0, min(p1, len(doc["paragraphs"]) - 1) + 1):
        text = doc["paragraphs"][index][side]
        low = o0 if index == p0 else 0
        high = o1 if index == p1 else len(text)
        for offset in range(low, min(high, len(text))):
            if not text[offset].isspace():
                return index, offset
    return None


# ---------------------------------------------------------------- rationales

def _kind_and_rationale(text: str):
    found = KIND_TAG.match(text)
    if found:
        return found.group(1), text[found.end():].strip()
    return "", text.strip()


def _comment_anchor(doc: dict, comment: dict) -> str:
    span = comment["span"]
    if span is None:
        print(f"comment {comment['id']} by {comment['author']} marks no range, so its anchor is empty")
        return ""
    for side in ("revised", "baseline"):
        found = _first_character(doc, side, span[side]["start"], span[side]["end"])
        if found is not None:
            sentence = _sentence_at(doc, side, found[0], found[1])
            if sentence is not None:
                return sentence[2]
    print(f"comment {comment['id']} by {comment['author']} covers no sentence, so its anchor is empty")
    return ""


def _comment_rationales(doc: dict, ai_author: str) -> list:
    out = []
    for comment in doc["comments"]:
        if comment["author"] != ai_author:
            continue
        kind, rationale = _kind_and_rationale(comment["text"])
        out.append({"anchor": _comment_anchor(doc, comment), "kind": kind, "rationale": rationale})
    return out


def _annotation_rationales(path: str) -> list:
    """The rationales from the YAML list annotate read, each read as the comment annotate writes from it."""
    try:
        items = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError, yaml.YAMLError) as error:
        raise AdapterError(f"{path} cannot be read as YAML, {error}")
    if not isinstance(items, list):
        raise AdapterError(f"{path} is not a YAML list of annotations")
    out = []
    for number, item in enumerate(items, 1):
        if not isinstance(item, dict) or "anchor" not in item or "text" not in item:
            raise AdapterError(f"annotation {number} in {path} needs anchor and text")
        tag = item.get("tag")
        body = f"[{tag}] {item['text']}" if tag else str(item["text"])
        kind, rationale = _kind_and_rationale(body)
        out.append({"anchor": str(item["anchor"]), "kind": kind, "rationale": rationale})
    return out


# ---------------------------------------------------------------- author edits

def _plain_segments(paragraph: dict) -> list:
    """The text a paragraph keeps on both sides, as (baseline start, revised start, length).

    Its changes are in document order, so the text between two of them is
    plain. An empty list means the sides do not line up as expected.
    """
    base, rev = paragraph["baseline"], paragraph["revised"]
    b = r = 0
    segments = []
    for change in paragraph["changes"]:
        if change["side"] == "baseline":
            length = change["start"] - b
            if length < 0:
                return []
            segments.append((b, r, length))
            b, r = change["end"], r + length
        else:
            length = change["start"] - r
            if length < 0:
                return []
            segments.append((b, r, length))
            b, r = b + length, change["end"]
    tail = len(base) - b
    if tail < 0 or r + tail != len(rev):
        return []
    segments.append((b, r, tail))
    if any(base[b0:b0 + n] != rev[r0:r0 + n] for b0, r0, n in segments):
        return []
    return segments


def _change_anchor(doc: dict, index: int, change: dict):
    """The sentence holding a tracked change.

    A change on the revised side gives the revised sentence holding its first
    character. A deletion gives the revised form of the baseline sentence
    holding it, found through a character the sentence keeps on both sides,
    or the baseline sentence itself when none is kept.
    """
    paragraph = doc["paragraphs"][index]
    side = change["side"]
    found = _first_character(doc, side, [index, change["start"]], [index, change["end"]])
    if found is None:
        return None
    sentence = _sentence_at(doc, side, index, found[1])
    if sentence is None or side == "revised":
        return sentence[2] if sentence else None
    s0, s1, text = sentence
    for b0, r0, length in _plain_segments(paragraph):
        for offset in range(max(b0, s0), min(b0 + length, s1)):
            if not paragraph["baseline"][offset].isspace():
                revised = _sentence_at(doc, "revised", index, r0 + offset - b0)
                return revised[2] if revised else text
    return text


def _author_edits(doc: dict, ai_author: str) -> list:
    seen, out = set(), []
    for index, paragraph in enumerate(doc["paragraphs"]):
        for change in paragraph["changes"]:
            if change["author"] == ai_author:
                continue
            anchor = _change_anchor(doc, index, change)
            if anchor is None or anchor in seen:
                continue
            seen.add(anchor)
            out.append({
                "id": f"a{len(out) + 1:02d}",
                "anchor": anchor,
                "note": f"tracked change by {change['author']}",
            })
    return out


# ---------------------------------------------------------------- versions

def _cells(line: str):
    line = line.strip()
    if len(line) < 2 or not (line.startswith("|") and line.endswith("|")):
        return None
    return [cell.strip() for cell in line[1:-1].split("|")]


def _sha_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _versions(builds_dir: str, version: str, read_paths: list):
    """The versions list and, when it is empty, why."""
    if builds_dir is None:
        return [], "since --builds-dir and --baseline-version were not given"
    ledger = Path(builds_dir) / LEDGER
    try:
        lines = ledger.read_text(encoding="utf-8").splitlines()
    except (OSError, ValueError) as error:
        return [], f"since {ledger} cannot be read, {error}"
    read_paths.append(str(ledger))
    header = None
    for line in lines:
        cells = _cells(line)
        if cells is None:
            continue
        names = [cell.lower() for cell in cells]
        if header is None:
            if "version" in names and "sha256" in names:
                if len(cells) not in (7, 9):
                    return [], f"since the header of {ledger} has {len(cells)} columns, not seven or nine"
                header = names
            continue
        if len(cells) != len(header) or cells[header.index("version")] != version:
            continue
        build = Path(builds_dir) / f"{version}.docx"
        try:
            data = build.read_bytes()
        except OSError as error:
            return [], f"since {build.name} cannot be read, {error}"
        read_paths.append(str(build))
        recorded = cells[header.index("sha256")].lower()
        if recorded.startswith("sha256:"):
            recorded = recorded[len("sha256:"):]
        actual = _sha_hex(data)
        if actual != recorded:
            return [], (
                f"since {build.name} no longer matches its {LEDGER} row, "
                f"sha256 {actual} on disk and {recorded} in the ledger"
            )
        try:
            text = side_text(read_docx(build), "revised")
        except DocxError as error:
            raise AdapterError(str(error))
        sha = "sha256:" + _sha_hex(text.encode("utf-8"))
        return [{"version": version, "file": build.name, "sha256": sha}], None
    if header is None:
        return [], f"since {ledger} has no header naming version and sha256"
    return [], f"since {ledger} has no row for {version}"


# ---------------------------------------------------------------- the adapter

def _dump(data) -> bytes:
    return yaml.safe_dump(data, sort_keys=False, default_flow_style=False, allow_unicode=True).encode("utf-8")


def read(args):
    if (args.builds_dir is None) != (args.baseline_version is None):
        raise AdapterError("--builds-dir and --baseline-version go together, give both or neither")
    try:
        doc = read_docx(args.docx)
    except DocxError as error:
        raise AdapterError(str(error))
    read_paths = [args.docx]

    if args.annotations is not None:
        rationales = _annotation_rationales(args.annotations)
        read_paths.append(args.annotations)
    else:
        rationales = _comment_rationales(doc, args.ai_author)
    rationales = [dict({"id": f"r{n:02d}"}, **r) for n, r in enumerate(rationales, 1)]

    versions, why = _versions(args.builds_dir, args.baseline_version, read_paths)
    if why:
        print(f"versions.yaml lists no version {why}, so the prose procedure reports the diff as unanchored")

    files = {
        "baseline.md": side_text(doc, "baseline").encode("utf-8"),
        "revised.md": side_text(doc, "revised").encode("utf-8"),
        "rationales.yaml": _dump(rationales),
        "author_edits.yaml": _dump(_author_edits(doc, args.ai_author)),
        "versions.yaml": _dump({"versions": versions}),
    }
    return read_paths, files


ADAPTER = Adapter("word", "prose", FILLS, add_arguments, read)
ADAPTERS[ADAPTER.name] = ADAPTER
