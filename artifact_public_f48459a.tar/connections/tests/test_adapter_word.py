"""Tests for the Word adapter (Track D, step D19).

Appendix-only. Table A6 lists an adapter for Word as specified and notes that
the adapter that fills the prose stream's files is not built. A2.5 Prose says
that for Word, programs show AI changes as tracked changes and then read back
the scholar's responses, and the A2.2 Adapters bullet names an adapter from a
Word document with tracked changes to the files the prose procedure checks.

The adapter writes baseline.md, revised.md, rationales.yaml, author_edits.yaml,
and versions.yaml (Track D choices 12, 14, and 15). In Word the AI's rationale
is a margin comment under the AI's author name on the sentence it explains,
whose text starts with the change kind in brackets.

Every document here is built by the test with docx_builder.py from the prose
procedure's seeded and clean fixtures, sentence by sentence. The prose
procedure is run offline through vg.py's command line with the fixture's
recorded answers, so no model or network is called. Every test runs with
HOME, CONNECTIONS_HOME, and AUDIT_HOME inside a temporary folder. Run from the
repository root with python3 -m pytest -q connections/tests.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
import yaml

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

import docx_builder  # noqa: E402
from connections.adapters import ADAPTERS  # noqa: E402
from connections.adapters.word import sentences  # noqa: E402
from connections.cli import main  # noqa: E402

VP = ROOT / "verification_procedures"
FIX = VP / "fixtures" / "prose"
SEEDED = FIX / "seeded"
CLEAN = FIX / "clean"
GRAPH = "graphs/prose.yaml"

AI = "AI Reviewer"
SCHOLAR = "Scholar"
FILLS = ("baseline.md", "revised.md", "rationales.yaml", "author_edits.yaml", "versions.yaml")
TITLE = (("Heading 1", [("plain", "Hiring practices and early turnover")]),)

# The seeded fixture's drafts as one Word document, sentence by sentence. Every
# AI change is a tracked change by the AI author, and the author's edit is a
# tracked change by the scholar.
SEEDED_PARAGRAPHS = TITLE + (
    (None, [
        ("plain", "Local governments face persistent difficulty retaining new hires. "),
        ("moveTo", "Prior work has focused mainly on private firms. ", AI),
        ("del", "In this study we examine", AI),
        ("ins", "This study examines", AI),
        ("plain", " whether structured interviews are associated with lower first-year turnover in municipal"
                  " agencies. We draw on personnel records from "),
        ("del", "48", AI),
        ("ins", "52", AI),
        ("plain", " agencies in three states [@alvarez2019]. "),
        ("del", "Turnover in the first year is", AI),
        ("ins", "First-year turnover is especially", AI),
        ("plain", " costly for small agencies [@"),
        ("del", "kim2018", AI),
        ("ins", "park2020", AI),
        ("plain", "]."),
        ("moveFrom", " Prior work has focused mainly on private firms.", AI),
    ]),
    (None, [
        ("plain", "Structured interviews standardize the questions that every candidate answers. Managers in our"
                  " sample "),
        ("del", "described", AI),
        ("ins", "called", AI),
        ("plain", " the format "),
        ("del", "as ", AI),
        ("plain", "slow but fair. One clerk said the process \"felt like a "),
        ("del", "real", AI),
        ("ins", "genuine", AI),
        ("plain", " conversation about the "),
        ("del", "job", AI),
        ("ins", "work", AI),
        ("plain", ".\" Agencies "),
        ("del", "that ", SCHOLAR),
        ("plain", "adopted the format "),
        ("del", "did so ", SCHOLAR),
        ("plain", "for "),
        ("del", "a variety of", SCHOLAR),
        ("ins", "many", SCHOLAR),
        ("plain", " different reasons"),
        ("del", ", and those reasons varied a great deal", SCHOLAR),
        ("plain", "."),
    ]),
    (None, [
        ("plain", "The results "),
        ("del", "suggest", AI),
        ("ins", "show", AI),
        ("plain", " that structured interviews "),
        ("del", "may ", AI),
        ("plain", "reduce early exits by 9 percentage points. "),
        ("plain", "This pattern held across agencies of different sizes."),
        ("plain", " Future research should test whether the effect persists beyond the first year."),
        ("ins", " The next section turns to the interview protocol itself.", AI),
    ]),
)

# Where each of the seeded fixture's rationales sits, (paragraph, segment) to
# (paragraph, segment), in the fixture's order r01 to r08.
SEEDED_PLACES = [((1, 1), (1, 1)), ((1, 3), (1, 3)), ((1, 6), (1, 6)), ((1, 9), (1, 12)),
                 ((2, 7), (2, 10)), ((3, 2), (3, 2)), ((3, 8), (3, 8)), ((3, 6), (3, 6))]

CLEAN_PARAGRAPHS = TITLE + (
    (None, [
        ("plain", "Local governments face persistent difficulty retaining new hires. "),
        ("moveTo", "Prior work has focused mainly on private firms. ", AI),
        ("del", "In this study we examine", AI),
        ("ins", "This study examines", AI),
        ("plain", " whether structured interviews are associated with lower first-year turnover in municipal"
                  " agencies. We draw on personnel records from 48 agencies in three states [@alvarez2019]."),
        ("moveFrom", " Prior work has focused mainly on private firms.", AI),
    ]),
    (None, [
        ("plain", "Structured interviews "),
        ("del", "standardize the questions that every candidate answers", AI),
        ("ins", "ask every candidate the same questions in the same order", AI),
        ("plain", ". Managers in our sample described the format as slow but fair. One clerk said the process"
                  " \"felt like a real conversation about the job.\""),
        ("del", " Agencies that adopted the format did so for a variety of different reasons, and those reasons"
                " varied a great deal.", AI),
    ]),
    (None, [
        ("plain", "The results suggest that structured interviews may reduce early exits by 9 percentage points."
                  " This pattern held across agencies of different sizes. Future research should test whether"
                  " the effect persists beyond the first year."),
        ("ins", " The next section turns to the interview protocol itself.", AI),
    ]),
)

CLEAN_PLACES = [((1, 1), (1, 1)), ((1, 3), (1, 3)), ((2, 2), (2, 2)), ((2, 4), (2, 4)), ((3, 1), (3, 1))]

LEDGER_NINE = (
    "# Builds\n\n"
    "| version | date | git | sha256 | purpose | baseline | reviewed | verification | runs |\n"
    "|---|---|---|---|---|---|---|---|---|\n"
    "| v001 | 2026-10-29 | - | {sha} | draft for review | - | no | verified | - |\n"
)
LEDGER_SEVEN = (
    "# Builds\n\n"
    "| version | date | git | sha256 | purpose | baseline | reviewed |\n"
    "|---|---|---|---|---|---|---|\n"
    "| v001 | 2026-10-29 | - | {sha} | draft for review | - | no |\n"
)


@pytest.fixture(autouse=True)
def homes(tmp_path, monkeypatch):
    user = tmp_path / "user"
    user.mkdir()
    monkeypatch.setenv("HOME", str(user))
    monkeypatch.setenv("CONNECTIONS_HOME", str(tmp_path / "connections_home"))
    monkeypatch.setenv("AUDIT_HOME", str(tmp_path / "audit_home"))
    return tmp_path


def fixture_rationales(fixture):
    return yaml.safe_load((fixture / "rationales.yaml").read_text(encoding="utf-8"))


def comments_for(fixture, places):
    """One comment by the AI author per fixture rationale, its kind tag first, in the fixture's order."""
    return [(AI, "[{}] {}".format(r["kind"], r["rationale"]), first, last)
            for r, (first, last) in zip(fixture_rationales(fixture), places)]


def build_review(path, paragraphs, comments):
    return docx_builder.build(path, list(paragraphs), comments)


def baseline_build(folder, fixture, ledger=LEDGER_NINE):
    """builds/v001.docx holding the fixture's baseline as plain text, and a BUILDS.md row for it."""
    folder.mkdir(parents=True, exist_ok=True)
    blocks = (fixture / "baseline.md").read_text(encoding="utf-8").rstrip("\n").split("\n\n")
    paragraphs = []
    for block in blocks:
        if block.startswith("# "):
            paragraphs.append(("Heading 1", [("plain", block[2:])]))
        else:
            paragraphs.append((None, [("plain", block)]))
    docx = docx_builder.build(folder / "v001.docx", paragraphs)
    sha = hashlib.sha256(docx.read_bytes()).hexdigest()
    (folder / "BUILDS.md").write_text(ledger.format(sha=sha), encoding="utf-8")
    return folder


def adapt(out, docx, *extra):
    return main(["adapt", "word", "--out", str(out), "--docx", str(docx), "--ai-author", AI] + list(extra))


def adapt_seeded(tmp_path, name="out", paragraphs=SEEDED_PARAGRAPHS, comments=None, extra=None):
    review = build_review(tmp_path / (name + "_review.docx"), paragraphs,
                          comments_for(SEEDED, SEEDED_PLACES) if comments is None else comments)
    builds = tmp_path / "builds"
    if not (builds / "BUILDS.md").exists():
        baseline_build(builds, SEEDED)
    args = ["--builds-dir", str(builds), "--baseline-version", "v001"] if extra is None else extra
    out = tmp_path / name
    assert adapt(out, review, *args) == 0
    return out


def load(out, name):
    return yaml.safe_load((out / name).read_text(encoding="utf-8"))


def vg(*args):
    env = dict(os.environ, VG_OFFLINE="1")
    return subprocess.run(
        [sys.executable, str(VP / "vg.py")] + list(args),
        cwd=str(VP),
        capture_output=True,
        text=True,
        env=env,
    )


def run_prose(out, fixture, run, tmp_path):
    inputs = tmp_path / (run.name + "_inputs")
    inputs.mkdir()
    for name in FILLS:
        shutil.copyfile(str(out / name), str(inputs / name))
    done = vg("run", GRAPH, "--run", str(run), "--inputs", str(inputs),
              "--judge", "recorded:" + str(fixture / "recorded_judge.json"))
    assert done.returncode == 0, done.stdout + done.stderr
    return run


def problems(run):
    findings = json.loads((run / "files" / "findings.json").read_text(encoding="utf-8"))
    return [f for f in findings if f["severity"] in ("blocking", "warning")]


def test_the_word_adapter_is_registered_for_the_prose_stream():
    adapter = ADAPTERS["word"]
    assert adapter.stream == "prose"
    assert tuple(adapter.fills) == FILLS


def test_the_two_drafts_equal_the_fixtures_byte_for_byte(tmp_path):
    out = adapt_seeded(tmp_path)
    assert (out / "baseline.md").read_bytes() == (SEEDED / "baseline.md").read_bytes()
    assert (out / "revised.md").read_bytes() == (SEEDED / "revised.md").read_bytes()


def test_the_rationales_carry_the_fixtures_ids_anchors_kinds_and_texts(tmp_path):
    out = adapt_seeded(tmp_path)
    assert load(out, "rationales.yaml") == fixture_rationales(SEEDED)


def test_the_author_edit_carries_the_fixtures_anchor(tmp_path):
    out = adapt_seeded(tmp_path)
    fixture = yaml.safe_load((SEEDED / "author_edits.yaml").read_text(encoding="utf-8"))
    assert load(out, "author_edits.yaml") == [
        {"id": "a01", "anchor": fixture[0]["anchor"], "note": "tracked change by Scholar"}
    ]


def test_versions_pins_the_baseline_build(tmp_path):
    out = adapt_seeded(tmp_path)
    versions = load(out, "versions.yaml")["versions"]
    fixture = yaml.safe_load((SEEDED / "versions.yaml").read_text(encoding="utf-8"))["versions"]
    assert versions == [{"version": "v001", "file": "v001.docx", "sha256": fixture[0]["sha256"]}]
    digest = "sha256:" + hashlib.sha256((out / "baseline.md").read_bytes()).hexdigest()
    assert versions[0]["sha256"] == digest


def test_the_prose_procedure_catches_every_planted_fault_from_the_adapters_files(tmp_path):
    out = adapt_seeded(tmp_path)
    run = run_prose(out, SEEDED, tmp_path / "run_seeded", tmp_path)
    scored = vg("score", "--run", str(run), "--truth", str(SEEDED / "truth.yaml"))
    assert scored.returncode == 0, scored.stdout + scored.stderr
    score = json.loads((run / "score.json").read_text(encoding="utf-8"))
    assert score["faults"] == 10
    assert len(score["caught"]) == 10
    assert score["recall"] == 1.0
    truth = yaml.safe_load((SEEDED / "truth.yaml").read_text(encoding="utf-8"))
    flagged = {f["item"] for f in problems(run)}
    for clean_item in truth["not_flagged"]:
        assert clean_item["item"] not in flagged, clean_item


def test_the_clean_fixture_built_the_same_way_gives_no_blocking_finding_or_warning(tmp_path):
    review = build_review(tmp_path / "clean.docx", CLEAN_PARAGRAPHS, comments_for(CLEAN, CLEAN_PLACES))
    builds = baseline_build(tmp_path / "builds", CLEAN)
    out = tmp_path / "out"
    assert adapt(out, review, "--builds-dir", str(builds), "--baseline-version", "v001") == 0
    assert (out / "baseline.md").read_bytes() == (CLEAN / "baseline.md").read_bytes()
    assert (out / "revised.md").read_bytes() == (CLEAN / "revised.md").read_bytes()
    assert load(out, "rationales.yaml") == fixture_rationales(CLEAN)
    assert load(out, "author_edits.yaml") == []
    run = run_prose(out, CLEAN, tmp_path / "run_clean", tmp_path)
    assert problems(run) == []


def test_a_comment_on_deleted_text_only_anchors_the_baseline_sentence(tmp_path):
    review = build_review(tmp_path / "clean.docx", CLEAN_PARAGRAPHS, comments_for(CLEAN, CLEAN_PLACES))
    out = tmp_path / "out"
    assert adapt(out, review) == 0
    deleted = [r for r in load(out, "rationales.yaml") if r["kind"] == "delete"]
    assert deleted == [{
        "id": "r04",
        "anchor": "Agencies that adopted the format did so for a variety of different reasons, and those reasons"
                  " varied a great deal.",
        "kind": "delete",
        "rationale": "Deleted a redundant sentence that repeated itself and carried no evidence.",
    }]


def test_an_annotations_file_gives_the_same_rationales_as_the_comments(tmp_path):
    with_comments = adapt_seeded(tmp_path, name="commented")
    annotations = tmp_path / "annotations.yaml"
    annotations.write_text(yaml.safe_dump(
        [{"anchor": r["anchor"], "text": r["rationale"], "tag": r["kind"]} for r in fixture_rationales(SEEDED)],
        sort_keys=False, allow_unicode=True,
    ), encoding="utf-8")
    review = build_review(tmp_path / "bare.docx", SEEDED_PARAGRAPHS, [])
    out = tmp_path / "annotated"
    assert adapt(out, review, "--annotations", str(annotations)) == 0
    assert (out / "rationales.yaml").read_bytes() == (with_comments / "rationales.yaml").read_bytes()
    record = json.loads((out / "adapter_record.json").read_text(encoding="utf-8"))
    assert str(annotations) in record["read"]


def test_an_annotations_file_overrides_the_documents_comments(tmp_path):
    annotations = tmp_path / "annotations.yaml"
    annotations.write_text("- anchor: This pattern held across agencies of different sizes.\n"
                           "  text: Kept as it was.\n", encoding="utf-8")
    review = build_review(tmp_path / "review.docx", SEEDED_PARAGRAPHS, comments_for(SEEDED, SEEDED_PLACES))
    out = tmp_path / "out"
    assert adapt(out, review, "--annotations", str(annotations)) == 0
    assert load(out, "rationales.yaml") == [{
        "id": "r01", "anchor": "This pattern held across agencies of different sizes.",
        "kind": "", "rationale": "Kept as it was.",
    }]


def test_a_build_that_no_longer_matches_its_ledger_row_gives_no_versions(tmp_path, capsys):
    builds = baseline_build(tmp_path / "builds", SEEDED)
    docx_builder.build(builds / "v001.docx", [(None, [("plain", "Changed after the build.")])])
    capsys.readouterr()
    out = adapt_seeded(tmp_path)
    assert load(out, "versions.yaml") == {"versions": []}
    printed = capsys.readouterr().out
    assert "v001.docx" in printed and "sha256" in printed


def test_without_the_build_options_versions_is_empty_and_says_why(tmp_path, capsys):
    out = adapt_seeded(tmp_path, extra=[])
    assert load(out, "versions.yaml") == {"versions": []}
    assert "--builds-dir" in capsys.readouterr().out


def test_a_version_the_ledger_lacks_gives_no_versions(tmp_path, capsys):
    out = adapt_seeded(tmp_path, extra=["--builds-dir", str(baseline_build(tmp_path / "builds", SEEDED)),
                                        "--baseline-version", "v002"])
    assert load(out, "versions.yaml") == {"versions": []}
    assert "v002" in capsys.readouterr().out


def test_a_seven_column_ledger_is_read_by_its_header_names(tmp_path):
    baseline_build(tmp_path / "builds", SEEDED, ledger=LEDGER_SEVEN)
    out = adapt_seeded(tmp_path)
    assert [v["version"] for v in load(out, "versions.yaml")["versions"]] == ["v001"]


def test_an_edit_made_without_tracked_changes_breaks_the_pin(tmp_path):
    paragraphs = list(SEEDED_PARAGRAPHS)
    last = list(paragraphs[3][1])
    last[7] = ("plain", " Future research should test whether the effect lasts beyond the first year.")
    paragraphs[3] = (None, last)
    out = adapt_seeded(tmp_path, paragraphs=paragraphs)
    versions = load(out, "versions.yaml")["versions"]
    digest = "sha256:" + hashlib.sha256((out / "baseline.md").read_bytes()).hexdigest()
    assert [v["version"] for v in versions] == ["v001"]
    assert versions[0]["sha256"] != digest


def test_a_comment_without_a_tag_gives_an_empty_kind(tmp_path):
    comments = [(AI, "Smoothed the opening.", (1, 3), (1, 3))]
    out = adapt_seeded(tmp_path, comments=comments)
    assert load(out, "rationales.yaml") == [{
        "id": "r01",
        "anchor": "This study examines whether structured interviews are associated with lower first-year turnover"
                  " in municipal agencies.",
        "kind": "",
        "rationale": "Smoothed the opening.",
    }]


def test_other_authors_comments_are_left_out(tmp_path):
    comments = [(SCHOLAR, "[edit] I made this one.", (2, 17), (2, 17)),
                (AI, "[edit] Changed the count.", (1, 6), (1, 6))]
    out = adapt_seeded(tmp_path, comments=comments)
    assert [(r["id"], r["rationale"]) for r in load(out, "rationales.yaml")] == [("r01", "Changed the count.")]


def test_no_comments_and_no_author_edits_give_empty_lists(tmp_path):
    review = build_review(tmp_path / "plain.docx", TITLE + ((None, [("plain", "Nothing changed here.")]),), [])
    out = tmp_path / "out"
    assert adapt(out, review) == 0
    assert (out / "rationales.yaml").read_text(encoding="utf-8") == "[]\n"
    assert (out / "author_edits.yaml").read_text(encoding="utf-8") == "[]\n"


def test_the_same_document_gives_the_same_bytes_in_two_folders(tmp_path):
    first = adapt_seeded(tmp_path, name="first")
    second = adapt_seeded(tmp_path, name="second")
    for name in FILLS:
        assert (first / name).read_bytes() == (second / name).read_bytes()


def test_the_build_folder_without_a_version_is_refused(tmp_path, capsys):
    review = build_review(tmp_path / "review.docx", SEEDED_PARAGRAPHS, [])
    out = tmp_path / "out"
    assert adapt(out, review, "--builds-dir", str(tmp_path)) == 1
    assert "--baseline-version" in capsys.readouterr().err
    assert not out.exists()


def test_a_file_that_is_not_a_word_document_is_refused(tmp_path, capsys):
    bad = tmp_path / "notes.docx"
    bad.write_text("plain text", encoding="utf-8")
    out = tmp_path / "out"
    assert adapt(out, bad) == 1
    assert "notes.docx" in capsys.readouterr().err
    assert not out.exists()


SAMPLE = (
    "# A heading. Not a sentence\n\n"
    "A first one. A second? Yes! He said \"stop.\" Then (aside) ok. She wrote “done.”"
    " “Next” came. It was 'over.' [Bracketed] next. Not e.g. here, and 3.5 stays.\n\n"
    "A second paragraph\nruns over a line break. Done."
)


def test_the_sentence_rule_splits_as_the_prose_procedure_does(tmp_path):
    inputs = tmp_path / "inputs"
    inputs.mkdir()
    (inputs / "baseline.md").write_text(SAMPLE, encoding="utf-8")
    (inputs / "revised.md").write_text("Zebra quilting xylophone.\n", encoding="utf-8")
    (inputs / "rationales.yaml").write_text("[]\n", encoding="utf-8")
    (inputs / "author_edits.yaml").write_text("[]\n", encoding="utf-8")
    (inputs / "versions.yaml").write_text("versions: []\n", encoding="utf-8")
    judge = tmp_path / "judge.json"
    judge.write_text("{}", encoding="utf-8")
    run = tmp_path / "run"
    done = vg("run", GRAPH, "--run", str(run), "--inputs", str(inputs), "--judge", "recorded:" + str(judge))
    assert done.returncode == 0, done.stdout + done.stderr
    changes = json.loads((run / "files" / "changes.json").read_text(encoding="utf-8"))
    deleted = [c["before"] for c in sorted(changes, key=lambda c: c["b_index"] if c["b_index"] is not None else -1)
               if c["kind"] == "delete"]
    assert sentences(SAMPLE) == deleted
    assert "He said \"stop.\"" in deleted and "It was 'over.'" in deleted


def test_an_author_deletion_of_a_whole_sentence_anchors_the_baseline_sentence(tmp_path):
    paragraphs = TITLE + ((None, [
        ("plain", "Most volunteers stayed."),
        ("del", " Some left early.", SCHOLAR),
        ("plain", " Training "),
        ("del", "clearly ", SCHOLAR),
        ("plain", "helped."),
    ]),)
    review = build_review(tmp_path / "review.docx", paragraphs, [])
    out = tmp_path / "out"
    assert adapt(out, review) == 0
    assert load(out, "author_edits.yaml") == [
        {"id": "a01", "anchor": "Some left early.", "note": "tracked change by Scholar"},
        {"id": "a02", "anchor": "Training helped.", "note": "tracked change by Scholar"},
    ]
